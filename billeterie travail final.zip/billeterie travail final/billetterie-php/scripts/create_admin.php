<?php
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    exit('CLI uniquement.');
}

require __DIR__ . '/../app/bootstrap.php';

[, $email, $password, $prenom, $nom] = array_pad($argv, 5, null);
if (!$email || !$password || strlen($password) < 8) {
    fwrite(STDERR, "Usage : php scripts/create_admin.php email motdepasse [prenom] [nom]\n");
    exit(1);
}

db()->prepare("INSERT INTO utilisateurs (nom, prenom, email, mot_de_passe_hash, role) VALUES (?, ?, ?, ?, 'admin')")
    ->execute([$nom ?: 'Admin', $prenom ?: 'Admin', mb_strtolower($email), password_hash($password, PASSWORD_DEFAULT)]);

echo "Administrateur créé : $email\n";
