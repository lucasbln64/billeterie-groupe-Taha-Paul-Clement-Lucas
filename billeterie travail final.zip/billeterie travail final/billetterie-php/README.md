# Fête & Sorties — billetterie en ligne

Application de réservation organisée comme l'exemple fourni : pages HTML regroupées par dossier,
JavaScript côté navigateur, API PHP et base relationnelle MySQL/MariaDB.

```text
Navigateur : HTML / CSS / JavaScript
           │ fetch + JSON + session
           ▼
Serveur : public/api/api.php (PHP)
           │ PDO
           ▼
Base : MySQL / MariaDB
```

## Dossiers et fichiers

### À la racine

- `README.md` : ce guide, avec les instructions d'installation, la description des composants et les tests.

### `app/` — code PHP partagé

- `bootstrap.php` : charge la configuration, règle le fuseau horaire, démarre la session et pose les en-têtes de sécurité ; il charge ensuite `functions.php`.
- `functions.php` : ouvre la connexion PDO à MySQL, retrouve l'utilisateur de la session, formate les dates et heures, et contient les règles métier pour réserver et annuler des billets.

### `config/` — paramètres du serveur

- `config.php` : lit les paramètres de connexion à la base dans les variables d'environnement, avec des valeurs locales par défaut. Il peut aussi charger `config.local.php` si tu crées ce fichier pour tes paramètres privés ; ce fichier local n'est pas fourni.

### `public/` — fichiers accessibles au navigateur

- `index.html` : entrée du site ; redirige vers la page d'accueil.
- `assets/` : dossier actuellement vide ; les pages utilisent les styles dans `css/` et les scripts dans `js/` ou dans leur dossier de page.
- `css/global.css` : styles communs aux différentes pages.
- `js/common.js` : client commun de l'API ; gère les requêtes `fetch`, la session, le jeton CSRF, la navigation selon la connexion et la déconnexion.
- `api/api.php` : point d'entrée de l'API JSON. Il vérifie et traite les requêtes, applique les droits, lit ou écrit les données par PDO, et renvoie les réponses au navigateur. Les routes GET servent la session, les événements, les réservations et les données d'administration ; les POST servent l'inscription, la connexion, la réservation, l'annulation et les modifications d'administration.
- `accueil/index.html` : contenu HTML de la page d'accueil et annonces mises en avant ; ses informations de disponibilité sont actualisées par JavaScript.
- `admin/index.html` : structure HTML du tableau de bord et des formulaires d'administration.
- `admin/script.js` : vérifie l'accès administrateur, charge les données et gère le tableau de bord, les tableaux, les formulaires et les actions CRUD.
- `admin/graphiques.js` : construit les barres des graphiques du tableau de bord.
- `admin/style.css` : styles spécifiques à l'administration : tableaux, formulaires, onglets, indicateurs et graphiques.
- `billet/index.html` : page qui affiche les billets d'une réservation.
- `billet/script.js` : charge les billets du compte connecté, affiche leurs références et déclenche l'impression.
- `billet/style.css` : règles d'impression des billets (masque notamment la navigation et le bouton d'impression).
- `connexion/index.html` : formulaire HTML de connexion.
- `connexion/script.js` : envoie les identifiants à l'API, affiche le résultat puis redirige après connexion.
- `evenement/index.html` : structure de la fiche détaillée d'un événement, avec le choix de séance et la réservation.
- `evenements/index.html` : structure de la liste des événements, des filtres et de la recherche.
- `evenements/script.js` : récupère les événements depuis l'API, filtre la liste et construit les cartes dans la page.
- `inscription/index.html` : formulaire HTML de création de compte.
- `inscription/script.js` : vérifie la confirmation du mot de passe puis envoie l'inscription à l'API.
- `reservations/index.html` : page de l'historique des réservations du compte connecté.
- `reservations/script.js` : affiche les disponibilités et les séances sur les pages d'accueil/événement, permet de réserver, affiche l'historique et gère l'annulation.

Les pages chargent `js/common.js` avant leur script spécifique lorsqu'elles communiquent avec l'API.
Les dossiers des pages regroupent ainsi leur HTML et, lorsqu'il y en a besoin, leur JavaScript et
leurs styles propres.

### `docs/` — documentation du projet

- `architecture.md` : architecture, routes de l'API, modèle de données, règles métier et sécurité.
- `journal.md` : journal de projet (dates et auteurs à compléter) et difficultés rencontrées.
- `soutenance.md` : plan de l'oral, scénario de démonstration et questions probables.

### `scripts/` — commandes d'administration technique

- `create_admin.php` : commande à lancer dans un terminal PHP pour créer un compte avec le rôle administrateur ; elle refuse d'être exécutée depuis le navigateur.

### `sql/` — structure et données de la base

- `schema.sql` : supprime puis recrée les tables `utilisateurs`, `categories`, `salles`, `evenements`, `seances`, `reservations` et `billets`, avec leurs clés et relations. **Son exécution efface les tables existantes.**
- `seed.sql` : ajoute les catégories, salles, événements et séances de démonstration.

### `tests/` — tests de l'API

- `api-smoke.php` : tests d'intégration qui vérifient les routes, les droits, les réservations et les fonctions d'administration. Il refuse toute base dont le nom ne finit pas par `_test`.

## Installation locale

Prérequis : PHP 8.1+ avec `pdo_mysql` et `mbstring`, et MySQL/MariaDB.

1. Créer la base puis importer les tables et les exemples :
   ```sh
   mysql -u root -p -e "CREATE DATABASE billetterie CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
   mysql -u root -p billetterie < sql/schema.sql
   mysql -u root -p billetterie < sql/seed.sql
   ```
   `schema.sql` supprime puis recrée les tables : ne l'importez pas sur une base qui contient des
   données à conserver.
2. Configurer `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASS`, ou créer
   `config/config.local.php` :
   ```php
   <?php return ['db_user' => 'root', 'db_pass' => 'secret'];
   ```
3. Créer un compte administrateur :
   ```sh
   php scripts/create_admin.php admin@exemple.fr MotDePasseSolide Prenom Nom
   ```
4. Depuis `billetterie-php`, démarrer le site :
   ```sh
   php -S localhost:8000 -t public
   ```
5. Ouvrir http://localhost:8000/ (redirige vers `public/accueil/`).

Ne pas ouvrir les pages directement depuis le système de fichiers et ne pas utiliser Live Server :
les formulaires et les données nécessitent PHP et MySQL.


## Fonctionnalités

- Consultation et recherche d'événements, catégories et séances à venir.
- Inscription, connexion et déconnexion avec mot de passe haché et session serveur.
- Choix d'une séance, réservation de billets, historique, annulation et références de billets.
- Impression des billets depuis la page « Mes billets » ; aucun paiement réel n'est effectué.
- Administration réservée au rôle `admin` : tableau de bord, statistiques de réservations et de
  recettes indicatives, gestion des événements, séances, catégories, salles et réservations.
- Les séances ayant des réservations ne peuvent pas être modifiées ou supprimées. Les suppressions
  d'événements, de salles et de catégories sont refusées lorsqu'elles invalideraient des réservations
  ou des références existantes.

## Comment le site fonctionne

1. Le navigateur affiche une page HTML et ses styles CSS.
2. Le JavaScript de la page réagit aux actions (rechercher, se connecter, réserver) et envoie une
   requête à `public/api/api.php` avec `fetch`.
3. L'API PHP vérifie les données, la session et les droits nécessaires. Pour une réservation, elle
   appelle les fonctions métier dans `app/functions.php`.
4. Ces fonctions utilisent PDO pour lire ou modifier MySQL/MariaDB. L'API renvoie ensuite du JSON,
   que le JavaScript utilise pour mettre à jour la page.

Par exemple, quand un utilisateur réserve deux billets, PHP vérifie que la séance existe et n'est
pas passée, puis contrôle les places disponibles dans une transaction. La transaction évite que
deux réservations simultanées prennent les mêmes dernières places. Si la réservation réussit, elle
et ses deux billets sont enregistrés ; sinon, l'API renvoie un message d'erreur.

La connexion est mémorisée dans une session serveur. Un jeton CSRF accompagne les requêtes qui
modifient des données. Pour l'administration, l'API revérifie le rôle administrateur à chaque
requête : masquer un bouton dans la page ne suffit jamais à autoriser une action.

## Sécurité

- PDO et requêtes préparées ; validation des entrées côté serveur.
- Sessions en cookie `HttpOnly`, régénérées à la connexion, et jeton CSRF pour les écritures.
- Les réservations et billets sont toujours filtrés selon le compte en session.
- Le rôle administrateur est vérifié sur chaque route d'administration par l'API, pas seulement dans
  l'interface.
- La capacité est contrôlée dans une transaction qui verrouille la séance.

## Tests d'intégration

Les tests effectuent des écritures : ils refusent toute base dont le nom ne finit pas par `_test`.
Utiliser une base dédiée avec les mêmes tables et données initiales :

```sh
mysql -u root -p -e "CREATE DATABASE billetterie_test CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
mysql -u root -p billetterie_test < sql/schema.sql
mysql -u root -p billetterie_test < sql/seed.sql
```

Configurer `DB_NAME=billetterie_test`, lancer le serveur PHP, puis :

```sh
php tests/api-smoke.php
```

Les tests d'accès administrateur et de CRUD complet sont exécutés si `TEST_ADMIN_EMAIL` et
`TEST_ADMIN_PASSWORD` désignent un administrateur créé dans cette base de test. L'API testée peut
être changée avec `TEST_BASE_URL`. Les tests créent un compte, des réservations et des objets
temporaires ; réinitialisez la base de test avant une nouvelle exécution complète.
