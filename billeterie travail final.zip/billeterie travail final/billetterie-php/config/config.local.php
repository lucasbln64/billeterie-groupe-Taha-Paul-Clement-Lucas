<?php
return ['db_name' => 'billeterie'];
