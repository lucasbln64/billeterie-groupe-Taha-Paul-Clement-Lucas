DROP TABLE IF EXISTS billets;
DROP TABLE IF EXISTS reservations;
DROP TABLE IF EXISTS seances;
DROP TABLE IF EXISTS evenements;
DROP TABLE IF EXISTS salles;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS utilisateurs;

CREATE TABLE utilisateurs (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nom VARCHAR(80) NOT NULL,
  prenom VARCHAR(80) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  mot_de_passe_hash VARCHAR(255) NOT NULL,
  role ENUM('user', 'admin') NOT NULL DEFAULT 'user',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE categories (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nom VARCHAR(80) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE salles (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nom VARCHAR(120) NOT NULL,
  adresse VARCHAR(190) NOT NULL,
  ville VARCHAR(80) NOT NULL,
  acces VARCHAR(190) NULL,
  capacite INT UNSIGNED NOT NULL CHECK (capacite > 0)
) ENGINE=InnoDB;

CREATE TABLE evenements (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  titre VARCHAR(150) NOT NULL,
  accroche VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  visuel VARCHAR(30) NOT NULL DEFAULT 'festival',
  categorie_id INT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_evenement_categorie FOREIGN KEY (categorie_id) REFERENCES categories (id)
) ENGINE=InnoDB;

CREATE TABLE seances (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  evenement_id INT UNSIGNED NOT NULL,
  salle_id INT UNSIGNED NOT NULL,
  debut DATETIME NOT NULL,
  fin DATETIME NULL,
  prix DECIMAL(8,2) NOT NULL DEFAULT 0,
  CONSTRAINT fk_seance_evenement FOREIGN KEY (evenement_id) REFERENCES evenements (id) ON DELETE CASCADE,
  CONSTRAINT fk_seance_salle FOREIGN KEY (salle_id) REFERENCES salles (id),
  INDEX idx_seance_debut (debut)
) ENGINE=InnoDB;

CREATE TABLE reservations (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  utilisateur_id INT UNSIGNED NOT NULL,
  seance_id INT UNSIGNED NOT NULL,
  nb_billets TINYINT UNSIGNED NOT NULL,
  statut ENUM('confirmee', 'annulee') NOT NULL DEFAULT 'confirmee',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_reservation_utilisateur FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs (id) ON DELETE CASCADE,
  CONSTRAINT fk_reservation_seance FOREIGN KEY (seance_id) REFERENCES seances (id) ON DELETE CASCADE,
  INDEX idx_reservation_seance_statut (seance_id, statut)
) ENGINE=InnoDB;

CREATE TABLE billets (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  reservation_id INT UNSIGNED NOT NULL,
  seance_id INT UNSIGNED NOT NULL,
  numero TINYINT UNSIGNED NOT NULL,
  reference CHAR(16) NOT NULL UNIQUE,
  CONSTRAINT fk_billet_reservation FOREIGN KEY (reservation_id) REFERENCES reservations (id) ON DELETE CASCADE,
  CONSTRAINT fk_billet_seance FOREIGN KEY (seance_id) REFERENCES seances (id) ON DELETE CASCADE
) ENGINE=InnoDB;
