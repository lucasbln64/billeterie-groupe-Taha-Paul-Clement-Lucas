INSERT INTO categories (id, nom) VALUES
  (1, 'Festival'), (2, 'Concert'), (3, 'Soirée'), (4, 'Marché'), (5, 'Fête');

INSERT INTO salles (id, nom, adresse, ville, acces, capacite) VALUES
  (1, 'Parc des Berges', 'Quai des Berges', 'Bordeaux', 'Tram C · arrêt Parc des Berges', 120),
  (2, 'La Verrière', '12 rue de la Verrière', 'Bordeaux', 'Tram B · arrêt Victoire', 80),
  (3, 'Le Grand Hall', '8 cours du Hall', 'Bordeaux', 'Tram A · arrêt Hôtel de Ville', 150),
  (4, 'Place de la Bourse', 'Place de la Bourse', 'Bordeaux', 'Tram C · arrêt Place de la Bourse', 300),
  (5, 'Jardin public', 'Cours de Verdun', 'Bordeaux', 'Tram C · arrêt Jardin public', 200);

INSERT INTO evenements (id, titre, accroche, description, visuel, categorie_id) VALUES
  (1, 'Nuits en Couleurs', 'Une nuit, plusieurs scènes, mille façons de la vivre.',
   'Une scène au bord de l’eau, des artistes à découvrir, toute la ville réunie.', 'festival', 1),
  (2, 'Le Salon Sonore', 'Une soirée live tout en cuivres et en groove.',
   'Une soirée live tout en cuivres, en groove et en proximité.', 'jazz', 2),
  (3, 'Minuit Minuit', 'Dansez jusqu’à ce que les lumières s’allument.',
   'Les meilleurs sons de la décennie, jusqu’à ce que les lumières s’allument.', 'dance', 3),
  (4, 'Marché de Noël en musique', 'Des stands, des idées de cadeaux et un concert.',
   'Des stands, des idées de cadeaux et un concert en plein air.', 'market', 4),
  (5, 'La Fête de l’hiver', 'Des animations pour petits et grands.',
   'Des animations et de la musique pour petits et grands.', 'winter', 5);

INSERT INTO seances (evenement_id, salle_id, debut, fin, prix) VALUES
  (1, 1, '2026-11-14 18:30:00', '2026-11-15 01:00:00', 29.00),
  (1, 1, '2026-11-15 18:30:00', '2026-11-16 00:00:00', 29.00),
  (2, 2, '2026-11-21 20:00:00', '2026-11-21 23:30:00', 39.00),
  (3, 3, '2026-12-05 22:00:00', '2026-12-06 05:00:00', 25.00),
  (4, 4, '2026-12-12 17:00:00', '2026-12-12 21:00:00', 8.00),
  (5, 5, '2026-12-19 14:00:00', '2026-12-19 19:00:00', 12.00);
