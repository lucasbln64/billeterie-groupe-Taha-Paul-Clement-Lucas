<?php
declare(strict_types=1);

class ReservationException extends RuntimeException
{
}

function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        global $config;
        $dsn = sprintf(
            'mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4',
            $config['db_host'],
            $config['db_port'],
            $config['db_name']
        );
        try {
            $pdo = new PDO($dsn, $config['db_user'], $config['db_pass'], [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
            $pdo->exec("SET time_zone = '" . date('P') . "'");
        } catch (PDOException $exception) {
            error_log($exception->getMessage());
            http_response_code(500);
            exit('Service temporairement indisponible.');
        }
    }
    return $pdo;
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function current_user(): ?array
{
    static $loaded = false;
    static $user = null;
    if (!$loaded) {
        $loaded = true;
        if (!empty($_SESSION['user_id'])) {
            $stmt = db()->prepare('SELECT id, nom, prenom, email, role FROM utilisateurs WHERE id = ?');
            $stmt->execute([(int) $_SESSION['user_id']]);
            $user = $stmt->fetch() ?: null;
            if ($user === null) {
                unset($_SESSION['user_id']);
            }
        }
    }
    return $user;
}

function format_date(string $datetime, bool $withWeekday = true): string
{
    static $days = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'];
    static $months = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
    $time = new DateTimeImmutable($datetime);
    $text = $time->format('j') . ' ' . $months[(int) $time->format('n') - 1] . ' ' . $time->format('Y');
    return $withWeekday ? $days[(int) $time->format('w')] . ' ' . $text : $text;
}

function format_time(string $datetime): string
{
    return (new DateTimeImmutable($datetime))->format('H \h i');
}

function visuel_class(string $visuel): string
{
    return in_array($visuel, ['festival', 'jazz', 'dance', 'market', 'winter'], true) ? 'thumb-' . $visuel : 'thumb-festival';
}

function reserve_billets(int $userId, int $seanceId, int $quantity): int
{
    global $config;
    if ($quantity < 1 || $quantity > $config['max_billets']) {
        throw new ReservationException('Choisissez entre 1 et ' . $config['max_billets'] . ' billets.');
    }

    $pdo = db();
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare('SELECT id, debut, salle_id FROM seances WHERE id = ? FOR UPDATE');
        $stmt->execute([$seanceId]);
        $seance = $stmt->fetch();
        if (!$seance || strtotime($seance['debut']) <= time()) {
            throw new ReservationException('Cette séance n’est pas disponible.');
        }

        $stmt = $pdo->prepare('SELECT capacite FROM salles WHERE id = ?');
        $stmt->execute([$seance['salle_id']]);
        $capacity = (int) $stmt->fetchColumn();

        $stmt = $pdo->prepare("SELECT COALESCE(SUM(nb_billets), 0) FROM reservations WHERE seance_id = ? AND statut = 'confirmee'");
        $stmt->execute([$seanceId]);
        $left = $capacity - (int) $stmt->fetchColumn();
        if ($left < $quantity) {
            throw new ReservationException($left > 0 ? "Il ne reste que $left place(s) pour cette séance." : 'Cette séance est complète.');
        }

        $stmt = $pdo->prepare('INSERT INTO reservations (utilisateur_id, seance_id, nb_billets) VALUES (?, ?, ?)');
        $stmt->execute([$userId, $seanceId, $quantity]);
        $reservationId = (int) $pdo->lastInsertId();

        $insert = $pdo->prepare('INSERT INTO billets (reservation_id, seance_id, numero, reference) VALUES (?, ?, ?, ?)');
        for ($number = 1; $number <= $quantity; $number++) {
            $insert->execute([$reservationId, $seanceId, $number, strtoupper(bin2hex(random_bytes(8)))]);
        }

        $pdo->commit();
        return $reservationId;
    } catch (Throwable $exception) {
        $pdo->rollBack();
        throw $exception;
    }
}

function cancel_reservation(int $userId, int $reservationId): bool
{
    $stmt = db()->prepare(
        "UPDATE reservations r JOIN seances s ON s.id = r.seance_id
         SET r.statut = 'annulee'
         WHERE r.id = ? AND r.utilisateur_id = ? AND r.statut = 'confirmee' AND s.debut > NOW()"
    );
    $stmt->execute([$reservationId, $userId]);
    return $stmt->rowCount() === 1;
}
