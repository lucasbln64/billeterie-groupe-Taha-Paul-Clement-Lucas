const loginForm = document.getElementById('loginForm');
const emailInput = document.getElementById('email');
const passwordInput = document.getElementById('password');
const togglePassword = document.getElementById('togglePassword');
const loginStatus = document.getElementById('loginStatus');

if (togglePassword && passwordInput) {
  togglePassword.addEventListener('click', () => {
    const showPassword = passwordInput.type === 'password';
    passwordInput.type = showPassword ? 'text' : 'password';
    togglePassword.textContent = showPassword ? 'Masquer' : 'Afficher';
    togglePassword.setAttribute('aria-label', showPassword ? 'Masquer le mot de passe' : 'Afficher le mot de passe');
    togglePassword.setAttribute('aria-pressed', String(showPassword));
  });
}

if (loginForm) {
  loginForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    loginStatus.textContent = 'Connexion en cours…';
    loginStatus.style.color = '#5d665f';

    const submitButton = loginForm.querySelector('button[type="submit"]');
    submitButton.disabled = true;

    try {
      const result = await window.apiRequest('/api/connexion', {
        method: 'POST',
        body: JSON.stringify({
          email: emailInput.value.trim(),
          password: passwordInput.value
        })
      });

      loginStatus.textContent = result.message || 'Connexion réussie. Redirection…';
      loginStatus.style.color = '#17604d';
      const returnPage = new URLSearchParams(window.location.search).get('retour') || '';
      const safeReturn = /^\.\.\/(?:accueil|evenements|evenement|reservations|billet|admin)\/(?:\?[a-zA-Z0-9_=&%-]*)?$/.test(returnPage)
        ? returnPage
        : '../accueil/';
      window.location.assign(safeReturn);
    } catch (error) {
      loginStatus.textContent = error.message === 'Failed to fetch'
        ? 'Le service de connexion est indisponible. Réessayez plus tard.'
        : error.message;
      loginStatus.style.color = '#a12d24';
      submitButton.disabled = false;
    }
  });
}
