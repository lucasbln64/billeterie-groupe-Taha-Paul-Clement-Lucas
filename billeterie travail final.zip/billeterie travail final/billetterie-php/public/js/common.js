// Client commun : JavaScript envoie les requêtes à l'API PHP, qui dialogue avec MySQL.
const API_URL = '../api/api.php';
let csrfToken = null;
let sessionRequest = null;

async function requestApi(route, options = {}) {
  const url = new URL(API_URL, window.location.href);
  const [path, query = ''] = route.split('?', 2);
  url.searchParams.set('route', path);
  new URLSearchParams(query).forEach((value, key) => url.searchParams.set(key, value));
  const headers = { ...options.headers };
  if (options.body) headers['Content-Type'] = 'application/json';

  const response = await fetch(url, {
    ...options,
    headers,
    credentials: 'same-origin'
  });
  let result;
  try {
    result = await response.json();
  } catch {
    throw new Error('Réponse invalide du serveur.');
  }
  if (!response.ok) {
    throw new Error(result.message || `Erreur serveur (${response.status}).`);
  }
  return result;
}

window.apiRequest = async function apiRequest(path, options = {}) {
  const apiPath = path.replace(/^\/api\/?/, '');
  const [route, query = ''] = apiPath.split('?', 2);
  const routeWithParams = query ? `${route}?${query}` : route;
  const requestOptions = { ...options };

  if (requestOptions.body && route !== 'session') {
    if (!csrfToken) {
      await window.loadSession();
    }
    requestOptions.headers = {
      ...requestOptions.headers,
      'X-CSRF-Token': csrfToken
    };
  }

  const result = await requestApi(routeWithParams, requestOptions);
  if (result.csrfToken) csrfToken = result.csrfToken;
  return result;
};

window.loadSession = function loadSession() {
  if (!sessionRequest) {
    sessionRequest = requestApi('session')
      .then((result) => {
        csrfToken = result.csrfToken;
        return result;
      })
      .catch((error) => {
        sessionRequest = null;
        throw error;
      });
  }
  return sessionRequest;
};

window.getCurrentUser = async function getCurrentUser() {
  const session = await window.loadSession();
  return session.user;
};

document.addEventListener('DOMContentLoaded', async () => {
  const accountLink = document.querySelector('.account-link');
  if (!accountLink) return;

  try {
    const user = await window.getCurrentUser();
    if (!user) return;

    accountLink.href = '../reservations/';
    const icon = accountLink.querySelector('svg');
    accountLink.replaceChildren(
      ...(icon ? [icon] : []),
      document.createTextNode('Mes réservations')
    );

    const logout = document.createElement('button');
    logout.className = 'nav-logout';
    logout.type = 'button';
    logout.textContent = 'Déconnexion';
    logout.addEventListener('click', async () => {
      logout.disabled = true;
      try {
        await window.apiRequest('/api/deconnexion', {
          method: 'POST',
          body: JSON.stringify({})
        });
        window.location.assign('../accueil/');
      } catch (error) {
        logout.disabled = false;
        window.alert(error.message);
      }
    });
    accountLink.after(logout);
    if (user.role === 'admin') {
      const adminLink = document.createElement('a');
      adminLink.href = '../admin/';
      adminLink.textContent = 'Administration';
      accountLink.after(adminLink);
    }
  } catch (error) {
    console.warn('Impossible de charger la session utilisateur :', error.message);
  }
});
