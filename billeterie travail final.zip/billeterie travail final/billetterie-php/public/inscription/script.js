const signupForm = document.getElementById('signupForm');
const signupStatus = document.getElementById('signupStatus');

if (signupForm) {
  signupForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    const prenom = document.getElementById('prenom').value.trim();
    const nom = document.getElementById('nom').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    const passwordConfirmation = document.getElementById('passwordConfirmation').value;
    const submitButton = signupForm.querySelector('button[type="submit"]');

    if (password !== passwordConfirmation) {
      signupStatus.textContent = 'Les deux mots de passe ne correspondent pas.';
      signupStatus.style.color = '#a12d24';
      return;
    }

    submitButton.disabled = true;
    signupStatus.textContent = 'Création du compte en cours…';
    signupStatus.style.color = '#5d665f';

    try {
      const result = await window.apiRequest('/api/inscription', {
        method: 'POST',
        body: JSON.stringify({ prenom, nom, email, password, passwordConfirmation })
      });
      signupStatus.textContent = result.message;
      signupStatus.style.color = '#17604d';
      window.setTimeout(() => window.location.assign('../connexion/'), 1000);
    } catch (error) {
      signupStatus.textContent = error.message === 'Failed to fetch'
        ? 'Le service est indisponible. Réessayez plus tard.'
        : error.message;
      signupStatus.style.color = '#a12d24';
      submitButton.disabled = false;
    }
  });
}
