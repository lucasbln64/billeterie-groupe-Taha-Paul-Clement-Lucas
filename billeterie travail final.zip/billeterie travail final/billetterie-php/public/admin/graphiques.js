window.renderAdminBars = function renderAdminBars(container, rows, labelKey, valueKey, formatter = (value) => String(value)) {
  container.replaceChildren();
  if (!rows.length) {
    const empty = document.createElement('p');
    empty.textContent = 'Aucune donnée pour cette période.';
    container.append(empty);
    return;
  }
  const maximum = Math.max(1, ...rows.map((row) => Number(row[valueKey]) || 0));
  rows.forEach((row) => {
    const line = document.createElement('div');
    line.className = 'admin-bar';
    const label = document.createElement('span');
    label.className = 'admin-bar-label';
    label.textContent = row[labelKey];
    const value = Number(row[valueKey]) || 0;
    const amount = document.createElement('strong');
    amount.textContent = formatter(value);
    const track = document.createElement('div');
    track.className = 'admin-bar-track';
    const bar = document.createElement('span');
    bar.style.width = `${Math.max(value > 0 ? 2 : 0, value / maximum * 100)}%`;
    track.append(bar);
    line.append(label, amount, track);
    container.append(line);
  });
};
