const accessBox = document.getElementById('admin-access');
const adminContent = document.getElementById('admin-content');
const statusMessage = document.getElementById('admin-status');
let adminDays = 30;
let events = [];
let categories = [];
let venues = [];
let sessions = [];
let reservations = [];

function showStatus(message, isError = false) {
  statusMessage.textContent = message;
  statusMessage.classList.toggle('is-error', isError);
}

function tableCell(row, value) {
  const cell = document.createElement('td');
  if (value instanceof Node) cell.append(value);
  else cell.textContent = value === null || value === undefined || value === '' ? '—' : String(value);
  row.append(cell);
}

function actionButton(label, callback, danger = false) {
  const button = document.createElement('button');
  button.type = 'button';
  button.className = danger ? 'button-light admin-danger' : 'button-light';
  button.textContent = label;
  button.addEventListener('click', callback);
  return button;
}

function renderTable(table, headers, rows, emptyMessage) {
  table.replaceChildren();
  const head = document.createElement('thead');
  const headRow = document.createElement('tr');
  headers.forEach((header) => tableCell(headRow, header));
  head.append(headRow);
  table.append(head);
  const body = document.createElement('tbody');
  if (!rows.length) {
    const row = document.createElement('tr');
    const cell = document.createElement('td');
    cell.colSpan = headers.length;
    cell.className = 'admin-table-empty';
    cell.textContent = emptyMessage;
    row.append(cell);
    body.append(row);
  } else {
    rows.forEach((values) => {
      const row = document.createElement('tr');
      values.forEach((value) => tableCell(row, value));
      body.append(row);
    });
  }
  table.append(body);
}

function actionCell(buttons) {
  const container = document.createElement('div');
  container.className = 'admin-row-actions';
  buttons.filter(Boolean).forEach((button) => container.append(button));
  return container;
}

function formValues(form) {
  return Object.fromEntries(new FormData(form).entries());
}

async function postAdmin(route, payload) {
  return window.apiRequest(`/api/admin/${route}`, {
    method: 'POST',
    body: JSON.stringify(payload)
  });
}

function resetForm(form, heading, title) {
  form.reset();
  form.elements.id.value = '';
  document.getElementById(heading).textContent = title;
}

function populateSelect(select, rows, idField, labelField, placeholder) {
  const selected = select.value;
  select.replaceChildren();
  const option = document.createElement('option');
  option.value = '';
  option.textContent = placeholder;
  select.append(option);
  rows.forEach((row) => {
    const item = document.createElement('option');
    item.value = String(row[idField]);
    item.textContent = row[labelField];
    select.append(item);
  });
  if (rows.some((row) => String(row[idField]) === selected)) select.value = selected;
}

async function loadCategories() {
  categories = (await window.apiRequest('/api/admin/categories')).categories;
  populateSelect(document.querySelector('#event-form [name="categoryId"]'), categories, 'id', 'nom', 'Choisir une catégorie');
}

async function loadVenues() {
  venues = (await window.apiRequest('/api/admin/venues')).venues;
  populateSelect(document.querySelector('#session-form [name="venueId"]'), venues, 'id', 'nom', 'Choisir une salle');
}

async function loadEvents() {
  events = (await window.apiRequest('/api/admin/events')).events;
  populateSelect(document.querySelector('#session-form [name="eventId"]'), events, 'id', 'titre', 'Choisir un événement');
  const table = document.getElementById('events-table');
  renderTable(table, ['Événement', 'Catégorie', 'Séances', 'Actions'], events.map((event) => {
    const actions = actionCell([
      actionButton('Modifier', () => editEvent(event)),
      actionButton('Supprimer', () => deleteRecord('events', event.id, 'cet événement', loadEvents), true)
    ]);
    return [event.titre, event.categorie, event.sessions, actions];
  }), 'Aucun événement enregistré.');
}

function editEvent(event) {
  const form = document.getElementById('event-form');
  form.elements.id.value = event.id;
  form.elements.title.value = event.titre;
  form.elements.tagline.value = event.accroche;
  form.elements.description.value = event.description;
  form.elements.categoryId.value = String(event.categorie_id);
  form.elements.visual.value = event.visuel;
  document.getElementById('event-form-title').textContent = 'Modifier un événement';
  form.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

async function loadSessions() {
  sessions = (await window.apiRequest('/api/admin/sessions')).sessions;
  renderTable(document.getElementById('sessions-table'), ['Événement / séance', 'Salle', 'Billets', 'Actions'], sessions.map((session) => {
    const booked = Number(session.reservations) > 0;
    const action = booked
      ? actionButton('Réservée', () => showStatus('Une séance avec des billets vendus ne peut pas être modifiée.', true))
      : actionButton('Modifier', () => editSession(session));
    const remove = actionButton('Supprimer', () => deleteRecord('sessions', session.id, 'cette séance', loadSessions), true);
    if (booked) remove.disabled = true;
    return [
      `${session.evenement} · ${new Date(String(session.debut).replace(' ', 'T')).toLocaleString('fr-FR')}`,
      `${session.salle} · ${session.capacite} places`,
      `${session.billets_vendus} / ${session.capacite}`,
      actionCell([action, remove])
    ];
  }), 'Aucune séance planifiée.');
}

function editSession(session) {
  const form = document.getElementById('session-form');
  form.elements.id.value = session.id;
  form.elements.eventId.value = String(session.evenement_id);
  form.elements.venueId.value = String(session.salle_id);
  form.elements.start.value = String(session.debut).replace(' ', 'T').slice(0, 16);
  form.elements.end.value = session.fin ? String(session.fin).replace(' ', 'T').slice(0, 16) : '';
  form.elements.price.value = session.prix;
  document.getElementById('session-form-title').textContent = 'Modifier une séance';
  form.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

async function loadVenuesTable() {
  await loadVenues();
  renderTable(document.getElementById('venues-table'), ['Salle', 'Ville', 'Capacité', 'Actions'], venues.map((venue) => [
    venue.nom,
    venue.ville,
    `${venue.capacite} places · ${venue.sessions} séance(s)`,
    actionCell([
      actionButton('Modifier', () => editVenue(venue)),
      actionButton('Supprimer', () => deleteRecord('venues', venue.id, 'cette salle', loadVenuesTable), true)
    ])
  ]), 'Aucune salle enregistrée.');
}

function editVenue(venue) {
  const form = document.getElementById('venue-form');
  form.elements.id.value = venue.id;
  form.elements.name.value = venue.nom;
  form.elements.address.value = venue.adresse;
  form.elements.city.value = venue.ville;
  form.elements.access.value = venue.acces || '';
  form.elements.capacity.value = venue.capacite;
  document.getElementById('venue-form-title').textContent = 'Modifier une salle';
  form.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

async function loadCategoriesTable() {
  await loadCategories();
  renderTable(document.getElementById('categories-table'), ['Catégorie', 'Événements', 'Actions'], categories.map((category) => [
    category.nom,
    category.events,
    actionCell([
      actionButton('Modifier', () => editCategory(category)),
      actionButton('Supprimer', () => deleteRecord('categories', category.id, 'cette catégorie', loadCategoriesTable), true)
    ])
  ]), 'Aucune catégorie enregistrée.');
}

function editCategory(category) {
  const form = document.getElementById('category-form');
  form.elements.id.value = category.id;
  form.elements.name.value = category.nom;
  document.getElementById('category-form-title').textContent = 'Modifier une catégorie';
  form.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

async function loadReservations() {
  reservations = (await window.apiRequest('/api/admin/reservations')).reservations;
  renderTable(document.getElementById('reservations-table'), ['Client', 'Événement / date', 'Billets', 'Total', 'Statut', 'Actions'], reservations.map((reservation) => {
    const canCancel = reservation.statut === 'confirmee' && new Date(String(reservation.debut).replace(' ', 'T')) > new Date();
    return [
      `${reservation.prenom} ${reservation.nom} · ${reservation.email}`,
      `${reservation.evenement} · ${new Date(String(reservation.debut).replace(' ', 'T')).toLocaleString('fr-FR')}`,
      reservation.nb_billets,
      `${(Number(reservation.prix) * Number(reservation.nb_billets)).toLocaleString('fr-FR')} €`,
      reservation.statut === 'confirmee' ? 'Confirmée' : 'Annulée',
      canCancel
        ? actionCell([actionButton('Annuler', () => cancelReservation(reservation.id), true)])
        : '—'
    ];
  }), 'Aucune réservation.');
}

async function cancelReservation(id) {
  if (!window.confirm('Annuler cette réservation ? Les billets ne seront plus valables.')) return;
  try {
    const result = await postAdmin('reservations', { action: 'cancel', id });
    showStatus(result.message);
    await loadReservations();
  } catch (error) {
    showStatus(error.message, true);
  }
}

async function deleteRecord(route, id, label, reload) {
  if (!window.confirm(`Supprimer ${label} ?`)) return;
  try {
    const result = await postAdmin(route, { action: 'delete', id });
    showStatus(result.message);
    await reload();
  } catch (error) {
    showStatus(error.message, true);
  }
}

async function loadDashboard() {
  const dashboard = await window.apiRequest(`/api/admin/dashboard?days=${adminDays}`);
  const summary = dashboard.summary;
  const metrics = [
    ['Clients', summary.users],
    ['Événements', summary.events],
    ['Réservations confirmées', summary.reservations],
    ['Billets vendus', summary.tickets],
    ['Remplissage des séances à venir', `${summary.occupancy}%`],
    ['Recette indicative', `${Number(summary.revenue).toLocaleString('fr-FR')} €`]
  ];
  const container = document.getElementById('admin-metrics');
  container.replaceChildren();
  metrics.forEach(([label, value]) => {
    const tile = document.createElement('article');
    tile.className = 'admin-metric';
    const caption = document.createElement('span');
    caption.textContent = label;
    const amount = document.createElement('strong');
    amount.textContent = String(value);
    tile.append(caption, amount);
    container.append(tile);
  });
  const dailyRows = dashboard.daily.map((row) => ({
    label: new Date(`${row.day}T12:00:00`).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short' }),
    value: Number(row.tickets),
    detail: `${row.revenue} €`
  }));
  window.renderAdminBars(document.getElementById('admin-daily'), dailyRows, 'label', 'value', (value) => `${value} billets`);
  const topRows = dashboard.topEvents.map((row) => ({ label: row.name, value: Number(row.tickets) }));
  window.renderAdminBars(document.getElementById('admin-top-events'), topRows, 'label', 'value', (value) => `${value} billets`);
}

const loaders = {
  dashboard: loadDashboard,
  events: async () => { await loadCategories(); await loadEvents(); },
  sessions: async () => { await Promise.all([loadEvents(), loadVenues()]); await loadSessions(); },
  categories: loadCategoriesTable,
  venues: loadVenuesTable,
  reservations: loadReservations
};

async function openTab(name) {
  document.querySelectorAll('[data-admin-tab]').forEach((button) => {
    const active = button.dataset.adminTab === name;
    button.className = active ? 'button-dark' : 'button-light';
    button.setAttribute('aria-current', active ? 'page' : 'false');
  });
  document.querySelectorAll('[data-admin-panel]').forEach((panel) => {
    panel.hidden = panel.dataset.adminPanel !== name;
  });
  try {
    showStatus('');
    await loaders[name]();
  } catch (error) {
    showStatus(error.message, true);
  }
}

function bindForm(formId, route, headingId, defaultHeading, refresh) {
  const form = document.getElementById(formId);
  form.addEventListener('reset', () => {
    window.setTimeout(() => {
      form.elements.id.value = '';
      document.getElementById(headingId).textContent = defaultHeading;
    });
  });
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const data = formValues(form);
    const action = data.id ? 'update' : 'create';
    try {
      const result = await postAdmin(route, { ...data, action });
      resetForm(form, headingId, defaultHeading);
      showStatus(result.message);
      await refresh();
    } catch (error) {
      showStatus(error.message, true);
    }
  });
}

async function startAdmin() {
  try {
    const user = await window.getCurrentUser();
    if (!user) {
      accessBox.classList.add('admin-access-denied');
      accessBox.replaceChildren();
      const heading = document.createElement('h2');
      heading.textContent = 'Connexion requise';
      const link = document.createElement('a');
      link.className = 'button-dark';
      link.href = `../connexion/?retour=${encodeURIComponent('../admin/')}`;
      link.textContent = 'Se connecter';
      accessBox.append(heading, link);
      return;
    }
    if (user.role !== 'admin') {
      accessBox.classList.add('admin-access-denied');
      accessBox.replaceChildren();
      const heading = document.createElement('h2');
      heading.textContent = 'Accès réservé';
      const explanation = document.createElement('p');
      explanation.textContent = 'Cette page est accessible uniquement aux administrateurs.';
      accessBox.append(heading, explanation);
      return;
    }
    accessBox.hidden = true;
    adminContent.hidden = false;
    bindForm('event-form', 'events', 'event-form-title', 'Ajouter un événement', () => openTab('events'));
    bindForm('session-form', 'sessions', 'session-form-title', 'Ajouter une séance', () => openTab('sessions'));
    bindForm('category-form', 'categories', 'category-form-title', 'Ajouter une catégorie', () => openTab('categories'));
    bindForm('venue-form', 'venues', 'venue-form-title', 'Ajouter une salle', () => openTab('venues'));
    document.querySelectorAll('[data-admin-tab]').forEach((button) => button.addEventListener('click', () => openTab(button.dataset.adminTab)));
    document.querySelectorAll('[data-days]').forEach((button) => button.addEventListener('click', async () => {
      adminDays = Number(button.dataset.days);
      document.querySelectorAll('[data-days]').forEach((item) => {
        item.className = Number(item.dataset.days) === adminDays ? 'button-dark' : 'button-light';
      });
      await openTab('dashboard');
    }));
    await openTab('dashboard');
  } catch (error) {
    accessBox.classList.add('admin-access-denied');
    accessBox.textContent = `Impossible de vérifier les droits : ${error.message}`;
  }
}

startAdmin();
