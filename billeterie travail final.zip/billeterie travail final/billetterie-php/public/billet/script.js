const ticketList = document.getElementById('ticket-list');
const reservationId = new URLSearchParams(window.location.search).get('reservationId');
document.getElementById('ticket-print')?.addEventListener('click', () => window.print());

async function showTickets() {
  if (!reservationId || !/^\d+$/.test(reservationId)) {
    ticketList.textContent = 'Réservation introuvable.';
    return;
  }

  try {
    const user = await window.getCurrentUser();
    if (!user) {
      ticketList.textContent = 'Connectez-vous pour consulter vos billets.';
      const link = document.createElement('a');
      link.href = `../connexion/?retour=${encodeURIComponent(`../billet/?reservationId=${reservationId}`)}`;
      link.textContent = ' Se connecter';
      ticketList.append(link);
      return;
    }
    const result = await window.apiRequest('/api/reservations');
    const reservation = result.reservations.find((item) => String(item.id) === reservationId);
    if (!reservation) {
      ticketList.textContent = 'Réservation introuvable.';
      return;
    }

    ticketList.replaceChildren();
    if (reservation.cancelled) {
      const notice = document.createElement('p');
      notice.className = 'reservation-cancelled';
      notice.textContent = 'Cette réservation a été annulée : les billets ne sont plus valables.';
      ticketList.append(notice);
    }

    reservation.ticketReferences.forEach((reference, index) => {
      const ticket = document.createElement('article');
      ticket.className = 'ticket-card';
      const title = document.createElement('h2');
      title.textContent = reservation.name;
      const details = document.createElement('p');
      details.textContent = `${reservation.date} · ${reservation.location}`;
      const seatNumber = document.createElement('p');
      seatNumber.textContent = `Billet ${index + 1} sur ${reservation.ticketReferences.length}`;
      const ref = document.createElement('p');
      ref.className = 'ticket-ref';
      ref.textContent = reference;
      ticket.append(title, details, seatNumber, ref);
      ticketList.append(ticket);
    });
  } catch (error) {
    ticketList.textContent = error.message;
    if (error.message.includes('Connectez-vous')) {
      const link = document.createElement('a');
      link.href = `../connexion/?retour=${encodeURIComponent(`../billet/?reservationId=${reservationId}`)}`;
      link.textContent = ' Se connecter';
      ticketList.append(link);
    }
  }
}

showTickets();
