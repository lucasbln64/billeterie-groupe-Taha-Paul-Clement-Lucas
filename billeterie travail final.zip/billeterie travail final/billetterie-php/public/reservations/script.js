// Le navigateur communique avec l'API PHP ; l'identité vient de la session serveur.
async function getReservations() {
  const result = await window.apiRequest('/api/reservations');
  return result.reservations || [];
}

const eventPage = document.querySelector('.detail-hero');
const requestedEventId = new URLSearchParams(window.location.search).get('eventId');
const currentEventId = eventPage ? requestedEventId || 'nuits-en-couleurs' : null;
const eventDetailsFallback = {
  'nuits-en-couleurs': { id: 'nuits-en-couleurs', name: 'Nuits en Couleurs', category: 'FESTIVAL · PLEIN AIR', date: '14 novembre 2026', price: 29, location: 'Parc des Berges, Bordeaux', tagline: 'Une nuit, plusieurs scènes, mille façons de la vivre.', description: 'Une scène au bord de l’eau, des artistes à découvrir, toute la ville réunie.', hours: '18 h 30 — 01 h 00', access: 'Tram C · arrêt Parc des Berges' },
  'salon-sonore': { id: 'salon-sonore', name: 'Le Salon Sonore', category: 'CONCERT · JAZZ', date: '21 novembre 2026', price: 39, location: 'La Verrière, Bordeaux', tagline: 'Une soirée live tout en cuivres et en groove.', description: 'Une soirée live tout en cuivres, en groove et en proximité.', hours: '20 h 00 — 23 h 30', access: 'Tram B · arrêt Victoire' },
  'minuit-minuit': { id: 'minuit-minuit', name: 'Minuit Minuit', category: 'SOIRÉE · CLUB', date: '5 décembre 2026', price: 25, location: 'Le Grand Hall, Bordeaux', tagline: 'Dansez jusqu’à ce que les lumières s’allument.', description: 'Les meilleurs sons de la décennie, jusqu’à ce que les lumières s’allument.', hours: '22 h 00 — 05 h 00', access: 'Tram A · arrêt Hôtel de Ville' }
};
let availableEventSeats = null;
let selectedSessionId = null;
let selectedSession = null;
let requestedSessionId = new URLSearchParams(window.location.search).get('sessionId');
let currentSessions = [];

if (eventPage) renderEventDetails(eventDetailsFallback[currentEventId]);

function updateReserveButton() {
  const reserveButton = document.getElementById('reserve-event');
  const quantitySelect = document.getElementById('reserve-quantity');
  if (!reserveButton) return;

  const requestedSeats = Number(quantitySelect?.value || 1);
  const soldOut = availableEventSeats === 0;
  reserveButton.disabled = !selectedSessionId || soldOut || availableEventSeats === null || requestedSeats > availableEventSeats;

  if (soldOut) {
    reserveButton.textContent = 'Complet';
  } else {
    reserveButton.textContent = requestedSeats > 1 ? `Réserver ${requestedSeats} places` : 'Réserver une place';
  }
}

async function refreshEventInventory() {
  const indicators = [...document.querySelectorAll('[data-event-availability], .detail-hero ~ .detail-content .event-availability')];
  const priceElements = document.querySelectorAll('[data-event-price]');
  if (!indicators.length && !priceElements.length && !eventPage) return null;

  try {
    const result = await window.apiRequest('/api/events');
    const events = result.events || [];
    const eventsById = new Map(events.map((event) => [event.id, event]));

    indicators.forEach((indicator) => {
      const eventId = indicator.dataset.eventAvailability || currentEventId;
      const event = eventsById.get(eventId);
      if (!event) return;
      const availableSeats = Number(event.availableSeats);
      indicator.textContent = availableSeats === 0
        ? 'Complet'
        : `${availableSeats} place${availableSeats === 1 ? '' : 's'} disponible${availableSeats === 1 ? '' : 's'}`;
      indicator.classList.toggle('is-sold-out', availableSeats === 0);
      indicator.classList.toggle('is-low-stock', availableSeats > 0 && availableSeats <= 10);
    });

    priceElements.forEach((element) => {
      const event = eventsById.get(element.dataset.eventPrice);
      if (event) element.textContent = `${event.price} €`;
    });

    const selectedEvent = eventsById.get(currentEventId);
    selectedSession = null;
    if (eventPage && selectedEvent) {
      const sessionSelect = document.getElementById('event-session');
      const sessions = selectedEvent.sessions || [];
      currentSessions = sessions;
      selectedSession = sessions.find((session) => String(session.id) === requestedSessionId)
        || sessions.find((session) => Number(session.id) === selectedSessionId)
        || sessions[0] || null;
      selectedSessionId = selectedSession ? Number(selectedSession.id) : null;
      requestedSessionId = null;

      if (sessionSelect) {
        sessionSelect.replaceChildren();
        sessions.forEach((session) => {
          const option = document.createElement('option');
          option.value = String(session.id);
          option.textContent = `${session.date} · ${session.hours} · ${session.location} · ${session.availableSeats} places`;
          sessionSelect.append(option);
        });
        if (selectedSessionId) sessionSelect.value = String(selectedSessionId);
        sessionSelect.disabled = sessions.length < 2;
        if (!sessionSelect.dataset.bound) {
          sessionSelect.addEventListener('change', () => {
            selectedSession = currentSessions.find((session) => String(session.id) === sessionSelect.value) || null;
            selectedSessionId = selectedSession ? Number(selectedSession.id) : null;
            availableEventSeats = selectedSession ? Number(selectedSession.availableSeats) : 0;
            renderEventDetails(selectedEvent, selectedSession);
            const availability = eventPage.parentElement.querySelector('.event-availability');
            if (availability) {
              availability.textContent = availableEventSeats > 0
                ? `${availableEventSeats} place${availableEventSeats > 1 ? 's' : ''} disponible${availableEventSeats > 1 ? 's' : ''}`
                : 'Complet';
              availability.classList.toggle('is-sold-out', availableEventSeats === 0);
              availability.classList.toggle('is-low-stock', availableEventSeats > 0 && availableEventSeats <= 10);
            }
            updateQuantityOptions();
            updateReserveButton();
          });
          sessionSelect.dataset.bound = 'true';
        }
      }
      renderEventDetails(selectedEvent, selectedSession);
    } else {
      selectedSessionId = null;
    }
    availableEventSeats = eventPage
      ? selectedSession ? Number(selectedSession.availableSeats) : 0
      : selectedEvent ? Number(selectedEvent.availableSeats) : null;

    if (eventPage) {
      const indicator = eventPage.parentElement.querySelector('.event-availability');
      if (indicator && selectedEvent) {
        indicator.textContent = availableEventSeats === 0
          ? 'Complet'
          : `${availableEventSeats} place${availableEventSeats === 1 ? '' : 's'} disponible${availableEventSeats === 1 ? '' : 's'}`;
        indicator.classList.toggle('is-sold-out', availableEventSeats === 0);
        indicator.classList.toggle('is-low-stock', availableEventSeats > 0 && availableEventSeats <= 10);
      }

      const quantitySelect = document.getElementById('reserve-quantity');
      updateQuantityOptions();
    }
    updateReserveButton();
    return selectedEvent || events;
  } catch {
    indicators.forEach((indicator) => {
      indicator.textContent = 'Compteur hors ligne — démarrez l’API pour voir les places restantes';
      indicator.classList.remove('is-sold-out', 'is-low-stock');
    });
    availableEventSeats = null;
    updateReserveButton();
    return null;
  }
}

function updateQuantityOptions() {
  const quantitySelect = document.getElementById('reserve-quantity');
  if (!quantitySelect) return;
  const currentQuantity = Math.max(1, Number(quantitySelect.value) || 1);
  const maxQuantity = Math.min(8, Math.max(0, availableEventSeats || 0));
  quantitySelect.replaceChildren();
  if (maxQuantity === 0) {
    const option = document.createElement('option');
    option.value = '0';
    option.textContent = 'Aucune place disponible';
    quantitySelect.append(option);
    return;
  }
  for (let quantity = 1; quantity <= maxQuantity; quantity += 1) {
    const option = document.createElement('option');
    option.value = String(quantity);
    option.textContent = `${quantity} place${quantity > 1 ? 's' : ''}`;
    quantitySelect.append(option);
  }
  quantitySelect.value = String(Math.min(currentQuantity, maxQuantity));
}

function renderEventDetails(event, session = event) {
  const setText = (selector, value) => {
    const element = document.querySelector(selector);
    if (element && value) element.textContent = value;
  };
  if (!event) return;
  setText('#event-title', event.name);
  setText('#event-category', event.category);
  setText('#event-tagline', event.tagline);
  setText('#event-description', event.description);
  setText('#event-price', session?.price === null || session?.price === undefined ? '—' : `${session.price} €`);
  setText('#event-date', session?.date || 'Aucune séance à venir');
  setText('#event-hours', session?.hours || '—');
  setText('#event-location', session?.location || '—');
  setText('#event-access', session?.access || '—');
  const heroImage = document.querySelector('.detail-hero-image');
  if (heroImage) {
    heroImage.classList.remove('event-nuits-en-couleurs', 'event-salon-sonore', 'event-minuit-minuit');
    heroImage.classList.add(`event-${event.id}`);
  }
  document.title = `${event.name} — Fête & Sorties`;
}

async function showReservations() {
  const reservationList = document.getElementById('reservation-list');
  if (!reservationList) return;

  reservationList.replaceChildren();
  let reservations;
  try {
    const user = await window.getCurrentUser();
    if (!user) {
      const message = document.createElement('p');
      message.className = 'empty-reservations';
      message.textContent = 'Connectez-vous pour accéder à vos réservations.';
      const loginLink = document.createElement('a');
      loginLink.className = 'login-back-link';
      loginLink.href = '../connexion/';
      loginLink.textContent = 'Se connecter';
      reservationList.append(message, loginLink);
      return;
    }
    reservations = await getReservations();
  } catch (error) {
    const errorMessage = document.createElement('p');
    errorMessage.className = 'empty-reservations';
    errorMessage.textContent = error.message;
    reservationList.append(errorMessage);
    if (error.message.includes('Connectez-vous')) {
      const loginLink = document.createElement('a');
      loginLink.className = 'login-back-link';
      loginLink.href = '../connexion/';
      loginLink.textContent = 'Se connecter';
      reservationList.append(loginLink);
    }
    return;
  }

  if (reservations.length === 0) {
    const emptyMessage = document.createElement('p');
    emptyMessage.className = 'empty-reservations';
    emptyMessage.textContent = 'Aucune réservation pour le moment.';
    reservationList.append(emptyMessage);
    return;
  }

  const cards = document.createElement('div');
  cards.className = 'reservation-cards';

  reservations.forEach((reservation) => {
      const card = document.createElement('article');
      card.className = 'reservation-card';

      const dateParts = String(reservation.date || '').split(' ');
      const date = document.createElement('div');
      date.className = 'reservation-date';
      const day = document.createElement('strong');
      day.textContent = dateParts[0] || '—';
      const month = document.createElement('span');
      month.textContent = dateParts[1]?.slice(0, 3).toLocaleUpperCase('fr') || '';
      date.append(day, month);

      const details = document.createElement('div');
      details.className = 'reservation-details';
      const category = document.createElement('span');
      category.className = 'reservation-category';
      category.textContent = reservation.category || 'MUSIQUE';
      const name = document.createElement('h2');
      name.textContent = reservation.name || 'Événement';
      const location = document.createElement('p');
      location.className = 'reservation-location';
      location.textContent = reservation.location || 'Lieu indiqué sur la fiche de l’événement';
      details.append(category, name, location);

      const eventLink = document.createElement('a');
      eventLink.className = 'reservation-open';
      eventLink.href = `../billet/?reservationId=${encodeURIComponent(reservation.id)}`;
      eventLink.setAttribute('aria-label', `Voir les billets de ${reservation.name || ''}`);
      eventLink.textContent = 'Voir les billets';

      const footer = document.createElement('div');
      footer.className = 'reservation-card-footer';
      const status = document.createElement('span');
      status.className = reservation.cancelled ? 'reservation-cancelled' : 'reservation-confirmed';
      status.textContent = reservation.cancelled ? 'Réservation annulée' : 'Réservation confirmée';
      const quantity = Number(reservation.quantity) || 0;
      const seats = document.createElement('span');
      seats.className = 'reservation-seats';
      seats.textContent = `${quantity} place${quantity > 1 ? 's' : ''} réservée${quantity > 1 ? 's' : ''}`;
      const total = document.createElement('strong');
      total.className = 'reservation-total';
      total.textContent = Number.isFinite(Number(reservation.total))
        ? `${Number(reservation.total).toLocaleString('fr-FR')} €`
        : '';
      footer.append(status, seats, total);
      card.append(date, details, eventLink, footer);
      if (reservation.canCancel) {
        const cancelButton = document.createElement('button');
        cancelButton.className = 'reservation-open reservation-cancel';
        cancelButton.type = 'button';
        cancelButton.textContent = 'Annuler';
        cancelButton.addEventListener('click', async () => {
          cancelButton.disabled = true;
          try {
            await window.apiRequest('/api/annulation', {
              method: 'POST',
              body: JSON.stringify({ reservationId: reservation.id })
            });
            await showReservations();
          } catch (error) {
            cancelButton.disabled = false;
            window.alert(error.message);
          }
        });
        card.append(cancelButton);
      }
    cards.append(card);
  });

  reservationList.append(cards);
}

// Afficher la liste dès l'ouverture de la page.
showReservations();
refreshEventInventory();

// Réserver le nombre de places choisi en respectant le stock retourné par l'API.
const reserveButton = document.getElementById('reserve-event');
if (reserveButton) {
  const reservationMessage = document.getElementById('reservation-message');
  const quantitySelect = document.getElementById('reserve-quantity');
  quantitySelect?.addEventListener('change', updateReserveButton);

  reserveButton.addEventListener('click', async () => {
    reserveButton.disabled = true;
    reservationMessage.textContent = 'Réservation en cours…';
    try {
      await window.apiRequest('/api/reservations', {
        method: 'POST',
        body: JSON.stringify({
          sessionId: selectedSessionId,
          quantity: Number(quantitySelect?.value || 1)
        })
      });
      const quantity = Number(quantitySelect?.value || 1);
      reservationMessage.textContent = `${quantity} place${quantity > 1 ? 's ont été ajoutées' : ' a été ajoutée'} à vos réservations.`;
      await refreshEventInventory();
      updateReserveButton();
      showReservations();
    } catch (error) {
      reservationMessage.textContent = error.message;
      if (error.message.includes('Connectez-vous')) {
        const loginLink = document.createElement('a');
        loginLink.href = `../connexion/?retour=${encodeURIComponent(`../evenement/?eventId=${currentEventId}`)}`;
        loginLink.textContent = ' Se connecter pour réserver.';
        reservationMessage.append(loginLink);
      }
      await refreshEventInventory();
      updateReserveButton();
    }
  });
}
