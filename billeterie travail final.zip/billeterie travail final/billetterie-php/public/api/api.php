<?php
declare(strict_types=1);

require __DIR__ . '/../../app/bootstrap.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function api_response(array $payload, int $status = 200): never
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

function api_input(): array
{
    $raw = file_get_contents('php://input');
    if ($raw === false || strlen($raw) > 16384) {
        api_response(['message' => 'Requête trop volumineuse.'], 413);
    }
    $input = json_decode($raw ?: '', true);
    if (!is_array($input)) {
        api_response(['message' => 'Requête JSON invalide.'], 400);
    }
    return $input;
}

function api_verify_csrf(): void
{
    $sent = (string) ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    $expected = (string) ($_SESSION['csrf'] ?? '');
    if ($sent === '' || $expected === '' || !hash_equals($expected, $sent)) {
        api_response(['message' => 'Requête invalide. Actualisez la page puis réessayez.'], 403);
    }
}

function api_require_login(): array
{
    $user = current_user();
    if ($user === null) {
        api_response(['message' => 'Connectez-vous pour accéder à vos réservations.'], 401);
    }
    return $user;
}

function api_require_admin(): array
{
    $user = api_require_login();
    if ($user['role'] !== 'admin') {
        api_response(['message' => 'Accès réservé aux administrateurs.'], 403);
    }
    return $user;
}

function api_text(array $input, string $key, int $maxLength, bool $required = true): string
{
    $value = trim((string) ($input[$key] ?? ''));
    if (($required && $value === '') || mb_strlen($value) > $maxLength) {
        api_response(['message' => "Le champ « $key » est obligatoire et limité à $maxLength caractères."], 422);
    }
    return $value;
}

function api_positive_id(mixed $value, string $label): int
{
    $id = filter_var($value, FILTER_VALIDATE_INT);
    if ($id === false || $id < 1) {
        api_response(['message' => "$label invalide."], 422);
    }
    return $id;
}

function api_event_slug(string $title): string
{
    if ($title === 'Le Salon Sonore') {
        return 'salon-sonore';
    }
    $ascii = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $title);
    $slug = strtolower((string) ($ascii === false ? $title : $ascii));
    $slug = trim((string) preg_replace('/[^a-z0-9]+/', '-', $slug), '-');
    return $slug !== '' ? $slug : 'evenement';
}

function api_events(): array
{
    $events = db()->query(
        'SELECT e.id, e.titre, e.accroche, e.description, e.visuel, e.categorie_id, c.nom AS categorie
         FROM evenements e JOIN categories c ON c.id = e.categorie_id
         ORDER BY e.titre'
    )->fetchAll();
    $sessions = db()->query(
        "SELECT s.id, s.evenement_id, s.debut, s.fin, s.prix, sa.nom AS salle_nom, sa.ville, sa.acces,
                sa.capacite - COALESCE((
                    SELECT SUM(r.nb_billets) FROM reservations r
                    WHERE r.seance_id = s.id AND r.statut = 'confirmee'
                ), 0) AS places_restantes
         FROM seances s JOIN salles sa ON sa.id = s.salle_id
         WHERE s.debut > NOW()
         ORDER BY s.debut"
    )->fetchAll();
    $byEvent = [];
    foreach ($sessions as $session) {
        $start = $session['debut'];
        $byEvent[(int) $session['evenement_id']][] = [
            'id' => (int) $session['id'],
            'startDate' => $start,
            'date' => format_date($start),
            'hours' => format_time($start) . ($session['fin'] === null ? '' : ' — ' . format_time($session['fin'])),
            'price' => (float) $session['prix'],
            'location' => $session['salle_nom'] . ', ' . $session['ville'],
            'access' => $session['acces'] ?? '',
            'availableSeats' => max(0, (int) $session['places_restantes']),
        ];
    }

    return array_map(static function (array $event) use ($byEvent): array {
        $eventSessions = $byEvent[(int) $event['id']] ?? [];
        $next = $eventSessions[0] ?? null;
        return [
            'id' => api_event_slug($event['titre']),
            'databaseId' => (int) $event['id'],
            'name' => $event['titre'],
            'category' => $event['categorie'],
            'categoryId' => (int) $event['categorie_id'],
            'tagline' => $event['accroche'],
            'description' => $event['description'],
            'visualClass' => visuel_class($event['visuel']),
            'sessions' => $eventSessions,
            'sessionId' => $next['id'] ?? null,
            'date' => $next['date'] ?? '',
            'startDate' => $next['startDate'] ?? null,
            'hours' => $next['hours'] ?? '',
            'price' => $next['price'] ?? null,
            'location' => $next['location'] ?? '',
            'access' => $next['access'] ?? '',
            'availableSeats' => $next['availableSeats'] ?? 0,
        ];
    }, $events);
}

function api_admin_sessions(): array
{
    return db()->query(
        'SELECT s.id, s.evenement_id, s.salle_id, s.debut, s.fin, s.prix,
                e.titre AS evenement, sa.nom AS salle, sa.capacite,
                (SELECT COUNT(*) FROM reservations rx WHERE rx.seance_id = s.id) AS reservations,
                COALESCE((SELECT SUM(r.nb_billets) FROM reservations r
                          WHERE r.seance_id = s.id AND r.statut = \'confirmee\'), 0) AS billets_vendus
         FROM seances s JOIN evenements e ON e.id = s.evenement_id
         JOIN salles sa ON sa.id = s.salle_id
         ORDER BY s.debut DESC'
    )->fetchAll();
}

function api_admin_reservations(): array
{
    return db()->query(
        'SELECT r.id, r.nb_billets, r.statut, r.created_at, u.prenom, u.nom, u.email,
                e.titre AS evenement, s.debut, sa.nom AS salle, s.prix
         FROM reservations r JOIN utilisateurs u ON u.id = r.utilisateur_id
         JOIN seances s ON s.id = r.seance_id JOIN evenements e ON e.id = s.evenement_id
         JOIN salles sa ON sa.id = s.salle_id
         ORDER BY r.created_at DESC, r.id DESC'
    )->fetchAll();
}

function api_admin_dashboard(): array
{
    $period = filter_var($_GET['days'] ?? 30, FILTER_VALIDATE_INT);
    if (!in_array($period, [7, 30, 90], true)) {
        $period = 30;
    }
    $summary = db()->query(
        "SELECT (SELECT COUNT(*) FROM utilisateurs WHERE role = 'user') AS users,
                (SELECT COUNT(*) FROM evenements) AS events,
                (SELECT COUNT(*) FROM reservations WHERE statut = 'confirmee') AS reservations,
                (SELECT COALESCE(SUM(nb_billets), 0) FROM reservations WHERE statut = 'confirmee') AS tickets,
                (SELECT COALESCE(SUM(r.nb_billets * s.prix), 0)
                   FROM reservations r JOIN seances s ON s.id = r.seance_id
                   WHERE r.statut = 'confirmee') AS revenue,
                (SELECT COALESCE(SUM(sa.capacite), 0)
                   FROM seances s JOIN salles sa ON sa.id = s.salle_id
                   WHERE s.debut > NOW()) AS future_capacity,
                (SELECT COALESCE(SUM(r.nb_billets), 0)
                   FROM reservations r JOIN seances s ON s.id = r.seance_id
                   WHERE r.statut = 'confirmee' AND s.debut > NOW()) AS future_tickets"
    )->fetch();
    $daily = db()->query(
        "SELECT DATE(r.created_at) AS day, COUNT(*) AS reservations,
                COALESCE(SUM(r.nb_billets), 0) AS tickets,
                COALESCE(SUM(r.nb_billets * s.prix), 0) AS revenue
         FROM reservations r JOIN seances s ON s.id = r.seance_id
         WHERE r.statut = 'confirmee' AND r.created_at >= DATE_SUB(CURDATE(), INTERVAL $period DAY)
         GROUP BY DATE(r.created_at) ORDER BY day"
    );
    $topEvents = db()->prepare(
        "SELECT e.titre AS name, COALESCE(SUM(r.nb_billets), 0) AS tickets,
                COALESCE(SUM(r.nb_billets * s.prix), 0) AS revenue
         FROM evenements e LEFT JOIN seances s ON s.evenement_id = e.id
         LEFT JOIN reservations r ON r.seance_id = s.id AND r.statut = 'confirmee'
         GROUP BY e.id, e.titre ORDER BY tickets DESC, e.titre LIMIT 5"
    );
    $topEvents->execute();
    return [
        'period' => $period,
        'summary' => [
            'users' => (int) $summary['users'],
            'events' => (int) $summary['events'],
            'reservations' => (int) $summary['reservations'],
            'tickets' => (int) $summary['tickets'],
            'revenue' => (float) $summary['revenue'],
            'occupancy' => (int) $summary['future_capacity'] > 0
                ? round((int) $summary['future_tickets'] / (int) $summary['future_capacity'] * 100, 1)
                : 0,
        ],
        'daily' => $daily->fetchAll(),
        'topEvents' => $topEvents->fetchAll(),
    ];
}

function api_reservations(int $userId): array
{
    $stmt = db()->prepare(
        'SELECT r.id, r.nb_billets, r.statut, r.created_at, s.debut, s.prix,
                e.titre, e.visuel, e.id AS evenement_id, sa.nom AS salle_nom,
                sa.ville, c.nom AS categorie
         FROM reservations r
         JOIN seances s ON s.id = r.seance_id
         JOIN evenements e ON e.id = s.evenement_id
         JOIN categories c ON c.id = e.categorie_id
         JOIN salles sa ON sa.id = s.salle_id
         WHERE r.utilisateur_id = ?
         ORDER BY r.created_at DESC, r.id DESC'
    );
    $stmt->execute([$userId]);
    $rows = $stmt->fetchAll();

    foreach ($rows as &$reservation) {
        $reservation['eventId'] = api_event_slug($reservation['titre']);
        $reservation['name'] = $reservation['titre'];
        $reservation['category'] = $reservation['categorie'];
        $reservation['location'] = $reservation['salle_nom'] . ', ' . $reservation['ville'];
        $reservation['date'] = format_date($reservation['debut'], false);
        $reservation['quantity'] = (int) $reservation['nb_billets'];
        $reservation['total'] = (float) $reservation['prix'] * (int) $reservation['nb_billets'];
        $reservation['cancelled'] = $reservation['statut'] === 'annulee';
        $reservation['canCancel'] = !$reservation['cancelled'] && strtotime($reservation['debut']) > time();
        $reservation['ticketReferences'] = [];

        $tickets = db()->prepare('SELECT reference FROM billets WHERE reservation_id = ? ORDER BY numero');
        $tickets->execute([$reservation['id']]);
        $reservation['ticketReferences'] = array_column($tickets->fetchAll(), 'reference');
    }
    unset($reservation);

    return $rows;
}

$route = trim((string) ($_GET['route'] ?? ''), '/');
$method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));

try {
    if ($route === 'session' && $method === 'GET') {
        $user = current_user();
        api_response([
            'user' => $user === null ? null : [
                'id' => (int) $user['id'],
                'prenom' => $user['prenom'],
                'nom' => $user['nom'],
                'email' => $user['email'],
                'role' => $user['role'],
            ],
            'csrfToken' => csrf_token(),
        ]);
    }

    if ($route === 'events' && $method === 'GET') {
        api_response(['events' => api_events()]);
    }

    if ($route === 'reservations' && $method === 'GET') {
        $user = api_require_login();
        api_response(['reservations' => api_reservations((int) $user['id'])]);
    }

    if ($method === 'GET' && str_starts_with($route, 'admin/')) {
        api_require_admin();
        if ($route === 'admin/dashboard') {
            api_response(api_admin_dashboard());
        }
        if ($route === 'admin/events') {
            api_response(['events' => db()->query(
                'SELECT e.id, e.titre, e.accroche, e.description, e.visuel, e.categorie_id, c.nom AS categorie,
                        COUNT(DISTINCT s.id) AS sessions
                 FROM evenements e JOIN categories c ON c.id = e.categorie_id
                 LEFT JOIN seances s ON s.evenement_id = e.id
                 GROUP BY e.id, e.titre, e.accroche, e.description, e.visuel, e.categorie_id, c.nom
                 ORDER BY e.titre'
            )->fetchAll()]);
        }
        if ($route === 'admin/categories') {
            api_response(['categories' => db()->query(
                'SELECT c.id, c.nom, COUNT(e.id) AS events FROM categories c
                 LEFT JOIN evenements e ON e.categorie_id = c.id
                 GROUP BY c.id, c.nom ORDER BY c.nom'
            )->fetchAll()]);
        }
        if ($route === 'admin/venues') {
            api_response(['venues' => db()->query(
                'SELECT sa.id, sa.nom, sa.adresse, sa.ville, sa.acces, sa.capacite,
                        COUNT(DISTINCT s.id) AS sessions
                 FROM salles sa LEFT JOIN seances s ON s.salle_id = sa.id
                 GROUP BY sa.id, sa.nom, sa.adresse, sa.ville, sa.acces, sa.capacite
                 ORDER BY sa.nom'
            )->fetchAll()]);
        }
        if ($route === 'admin/sessions') {
            api_response(['sessions' => api_admin_sessions()]);
        }
        if ($route === 'admin/reservations') {
            api_response(['reservations' => api_admin_reservations()]);
        }
    }

    if (!in_array($method, ['POST'], true)) {
        api_response(['message' => 'Route introuvable.'], 404);
    }

    api_verify_csrf();
    $input = api_input();

    if (str_starts_with($route, 'admin/')) {
        api_require_admin();
        $action = (string) ($input['action'] ?? '');
        $id = $action === 'create' ? 0 : api_positive_id($input['id'] ?? null, 'Identifiant');
        $table = [
            'admin/events' => 'evenements',
            'admin/categories' => 'categories',
            'admin/venues' => 'salles',
            'admin/sessions' => 'seances',
        ][$route] ?? null;
        if ($table !== null && $action !== 'create') {
            $stmt = db()->prepare("SELECT id FROM $table WHERE id = ?");
            $stmt->execute([$id]);
            if (!$stmt->fetchColumn()) {
                api_response(['message' => 'Élément introuvable.'], 404);
            }
        }

        if ($route === 'admin/events') {
            if ($action === 'delete') {
                $stmt = db()->prepare(
                    'SELECT COUNT(*) FROM reservations r JOIN seances s ON s.id = r.seance_id WHERE s.evenement_id = ?'
                );
                $stmt->execute([$id]);
                if ((int) $stmt->fetchColumn() > 0) {
                    api_response(['message' => 'Impossible de supprimer un événement qui possède des réservations.'], 409);
                }
                db()->prepare('DELETE FROM evenements WHERE id = ?')->execute([$id]);
                api_response(['message' => 'Événement supprimé.']);
            }

            $title = api_text($input, 'title', 150);
            $tagline = api_text($input, 'tagline', 255);
            $description = api_text($input, 'description', 10000);
            $visual = api_text($input, 'visual', 30);
            $categoryId = api_positive_id($input['categoryId'] ?? null, 'Catégorie');
            if (!in_array($visual, ['festival', 'jazz', 'dance', 'market', 'winter'], true)) {
                api_response(['message' => 'Visuel invalide.'], 422);
            }
            if ($action === 'create') {
                db()->prepare(
                    'INSERT INTO evenements (titre, accroche, description, visuel, categorie_id) VALUES (?, ?, ?, ?, ?)'
                )->execute([$title, $tagline, $description, $visual, $categoryId]);
                api_response(['message' => 'Événement créé.', 'id' => (int) db()->lastInsertId()], 201);
            }
            if ($action === 'update') {
                db()->prepare(
                    'UPDATE evenements SET titre = ?, accroche = ?, description = ?, visuel = ?, categorie_id = ? WHERE id = ?'
                )->execute([$title, $tagline, $description, $visual, $categoryId, $id]);
                api_response(['message' => 'Événement modifié.']);
            }
            api_response(['message' => 'Action événement inconnue.'], 422);
        }

        if ($route === 'admin/categories') {
            if ($action === 'delete') {
                $stmt = db()->prepare('SELECT COUNT(*) FROM evenements WHERE categorie_id = ?');
                $stmt->execute([$id]);
                if ((int) $stmt->fetchColumn() > 0) {
                    api_response(['message' => 'Cette catégorie est utilisée par un ou plusieurs événements.'], 409);
                }
                db()->prepare('DELETE FROM categories WHERE id = ?')->execute([$id]);
                api_response(['message' => 'Catégorie supprimée.']);
            }
            $name = api_text($input, 'name', 80);
            if ($action === 'create') {
                db()->prepare('INSERT INTO categories (nom) VALUES (?)')->execute([$name]);
                api_response(['message' => 'Catégorie créée.'], 201);
            }
            if ($action === 'update') {
                db()->prepare('UPDATE categories SET nom = ? WHERE id = ?')->execute([$name, $id]);
                api_response(['message' => 'Catégorie modifiée.']);
            }
            api_response(['message' => 'Action catégorie inconnue.'], 422);
        }

        if ($route === 'admin/venues') {
            if ($action === 'delete') {
                $stmt = db()->prepare('SELECT COUNT(*) FROM seances WHERE salle_id = ?');
                $stmt->execute([$id]);
                if ((int) $stmt->fetchColumn() > 0) {
                    api_response(['message' => 'Cette salle est utilisée par une ou plusieurs séances.'], 409);
                }
                db()->prepare('DELETE FROM salles WHERE id = ?')->execute([$id]);
                api_response(['message' => 'Salle supprimée.']);
            }
            $name = api_text($input, 'name', 120);
            $address = api_text($input, 'address', 190);
            $city = api_text($input, 'city', 80);
            $access = api_text($input, 'access', 190, false);
            $capacity = filter_var($input['capacity'] ?? null, FILTER_VALIDATE_INT);
            if ($capacity === false || $capacity < 1 || $capacity > 1000000) {
                api_response(['message' => 'La capacité doit être comprise entre 1 et 1 000 000.'], 422);
            }
            if ($action === 'create') {
                db()->prepare(
                    'INSERT INTO salles (nom, adresse, ville, acces, capacite) VALUES (?, ?, ?, ?, ?)'
                )->execute([$name, $address, $city, $access ?: null, $capacity]);
                api_response(['message' => 'Salle créée.'], 201);
            }
            if ($action === 'update') {
                $stmt = db()->prepare(
                    'SELECT COALESCE(MAX(booked), 0) FROM (
                       SELECT COALESCE(SUM(r.nb_billets), 0) AS booked
                       FROM seances s LEFT JOIN reservations r ON r.seance_id = s.id AND r.statut = \'confirmee\'
                       WHERE s.salle_id = ? GROUP BY s.id
                     ) AS seat_counts'
                );
                $stmt->execute([$id]);
                if ($capacity < (int) $stmt->fetchColumn()) {
                    api_response(['message' => 'La capacité ne peut pas être inférieure au nombre de billets déjà vendus.'], 409);
                }
                db()->prepare(
                    'UPDATE salles SET nom = ?, adresse = ?, ville = ?, acces = ?, capacite = ? WHERE id = ?'
                )->execute([$name, $address, $city, $access ?: null, $capacity, $id]);
                api_response(['message' => 'Salle modifiée.']);
            }
            api_response(['message' => 'Action salle inconnue.'], 422);
        }

        if ($route === 'admin/sessions') {
            if ($action === 'delete') {
                $stmt = db()->prepare('SELECT COUNT(*) FROM reservations WHERE seance_id = ?');
                $stmt->execute([$id]);
                if ((int) $stmt->fetchColumn() > 0) {
                    api_response(['message' => 'Impossible de supprimer une séance avec des réservations.'], 409);
                }
                db()->prepare('DELETE FROM seances WHERE id = ?')->execute([$id]);
                api_response(['message' => 'Séance supprimée.']);
            }
            $eventId = api_positive_id($input['eventId'] ?? null, 'Événement');
            $venueId = api_positive_id($input['venueId'] ?? null, 'Salle');
            $start = api_text($input, 'start', 19);
            $end = api_text($input, 'end', 19, false);
            $price = filter_var($input['price'] ?? null, FILTER_VALIDATE_FLOAT);
            $startTime = DateTimeImmutable::createFromFormat('Y-m-d\TH:i', $start);
            $endTime = $end === '' ? null : DateTimeImmutable::createFromFormat('Y-m-d\TH:i', $end);
            if ($startTime === false || $startTime->format('Y-m-d\TH:i') !== $start
                || ($end !== '' && ($endTime === false || $endTime->format('Y-m-d\TH:i') !== $end))
                || ($endTime !== null && $endTime <= $startTime)
                || $price === false || $price < 0 || $price > 999999.99) {
                api_response(['message' => 'Date, horaires ou prix de séance invalide.'], 422);
            }
            if ($action === 'create') {
                db()->prepare(
                    'INSERT INTO seances (evenement_id, salle_id, debut, fin, prix) VALUES (?, ?, ?, ?, ?)'
                )->execute([$eventId, $venueId, $startTime->format('Y-m-d H:i:s'), $endTime?->format('Y-m-d H:i:s'), $price]);
                api_response(['message' => 'Séance créée.'], 201);
            }
            if ($action === 'update') {
                $stmt = db()->prepare('SELECT COUNT(*) FROM reservations WHERE seance_id = ?');
                $stmt->execute([$id]);
                if ((int) $stmt->fetchColumn() > 0) {
                    api_response(['message' => 'Une séance avec des réservations ne peut pas être modifiée.'], 409);
                }
                db()->prepare(
                    'UPDATE seances SET evenement_id = ?, salle_id = ?, debut = ?, fin = ?, prix = ? WHERE id = ?'
                )->execute([$eventId, $venueId, $startTime->format('Y-m-d H:i:s'), $endTime?->format('Y-m-d H:i:s'), $price, $id]);
                api_response(['message' => 'Séance modifiée.']);
            }
            api_response(['message' => 'Action séance inconnue.'], 422);
        }

        if ($route === 'admin/reservations' && $action === 'cancel') {
            $stmt = db()->prepare(
                "UPDATE reservations r JOIN seances s ON s.id = r.seance_id
                 SET r.statut = 'annulee'
                 WHERE r.id = ? AND r.statut = 'confirmee' AND s.debut > NOW()"
            );
            $stmt->execute([$id]);
            if ($stmt->rowCount() !== 1) {
                api_response(['message' => 'Cette réservation ne peut pas être annulée.'], 409);
            }
            api_response(['message' => 'Réservation annulée.']);
        }

        api_response(['message' => 'Route d’administration inconnue.'], 404);
    }

    if ($route === 'connexion') {
        $email = mb_strtolower(trim((string) ($input['email'] ?? '')));
        $password = (string) ($input['password'] ?? '');
        if (strlen($email) > 190 || strlen($password) > 1024) {
            api_response(['message' => 'Adresse e-mail ou mot de passe invalide.'], 422);
        }

        $stmt = db()->prepare('SELECT id, mot_de_passe_hash FROM utilisateurs WHERE email = ?');
        $stmt->execute([$email]);
        $row = $stmt->fetch();
        $hash = $row['mot_de_passe_hash'] ?? password_hash('dummy-password', PASSWORD_DEFAULT);
        if (!$row || !password_verify($password, $hash)) {
            api_response(['message' => 'Adresse e-mail ou mot de passe invalide.'], 422);
        }

        session_regenerate_id(true);
        $_SESSION['user_id'] = (int) $row['id'];
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
        if (password_needs_rehash($hash, PASSWORD_DEFAULT)) {
            db()->prepare('UPDATE utilisateurs SET mot_de_passe_hash = ? WHERE id = ?')
                ->execute([password_hash($password, PASSWORD_DEFAULT), $row['id']]);
        }
        api_response(['message' => 'Connexion réussie.', 'csrfToken' => csrf_token()]);
    }

    if ($route === 'inscription') {
        $prenom = trim((string) ($input['prenom'] ?? ''));
        $nom = trim((string) ($input['nom'] ?? ''));
        $email = mb_strtolower(trim((string) ($input['email'] ?? '')));
        $password = (string) ($input['password'] ?? '');
        $confirmation = (string) ($input['passwordConfirmation'] ?? '');
        $errors = [];

        foreach (['Prénom' => $prenom, 'Nom' => $nom] as $label => $value) {
            $length = mb_strlen($value);
            if ($length < 1 || $length > 80) {
                $errors[] = "$label obligatoire (80 caractères maximum).";
            }
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) {
            $errors[] = 'Adresse e-mail invalide.';
        }
        if (strlen($password) < 8 || strlen($password) > 128) {
            $errors[] = 'Le mot de passe doit contenir entre 8 et 128 caractères.';
        }
        if ($password !== $confirmation) {
            $errors[] = 'Les mots de passe ne correspondent pas.';
        }
        if ($errors) {
            api_response(['message' => implode(' ', $errors)], 422);
        }

        try {
            db()->prepare('INSERT INTO utilisateurs (nom, prenom, email, mot_de_passe_hash) VALUES (?, ?, ?, ?)')
                ->execute([$nom, $prenom, $email, password_hash($password, PASSWORD_DEFAULT)]);
        } catch (PDOException $exception) {
            if ($exception->getCode() !== '23000') {
                throw $exception;
            }
            api_response(['message' => 'Un compte existe déjà avec cette adresse e-mail.'], 409);
        }
        api_response(['message' => 'Compte créé. Vous pouvez maintenant vous connecter.'], 201);
    }

    if ($route === 'reservations') {
        $user = api_require_login();
        $sessionId = filter_var($input['sessionId'] ?? null, FILTER_VALIDATE_INT);
        $quantity = filter_var($input['quantity'] ?? null, FILTER_VALIDATE_INT);
        if ($sessionId === false || $sessionId < 1 || $quantity === false) {
            api_response(['message' => 'Séance ou nombre de billets invalide.'], 422);
        }
        try {
            $reservationId = reserve_billets((int) $user['id'], $sessionId, $quantity);
        } catch (ReservationException $exception) {
            api_response(['message' => $exception->getMessage()], 422);
        }
        api_response(['message' => 'Votre réservation est confirmée.', 'reservationId' => $reservationId], 201);
    }

    if ($route === 'annulation') {
        $user = api_require_login();
        $reservationId = filter_var($input['reservationId'] ?? null, FILTER_VALIDATE_INT);
        if ($reservationId === false || !$reservationId || !cancel_reservation((int) $user['id'], $reservationId)) {
            api_response(['message' => 'Cette réservation ne peut pas être annulée.'], 422);
        }
        api_response(['message' => 'Réservation annulée.']);
    }

    if ($route === 'deconnexion') {
        unset($_SESSION['user_id']);
        session_regenerate_id(true);
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
        api_response(['message' => 'Vous êtes déconnecté.']);
    }

    api_response(['message' => 'Route introuvable.'], 404);
} catch (Throwable $exception) {
    error_log($exception->getMessage());
    if ($exception instanceof PDOException && $exception->getCode() === '23000') {
        api_response(['message' => 'Cette modification entre en conflit avec des données existantes.'], 409);
    }
    api_response(['message' => 'Une erreur est survenue. Réessayez plus tard.'], 500);
}
