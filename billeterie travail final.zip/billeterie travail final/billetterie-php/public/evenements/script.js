const eventList = document.querySelector('.event-list');
const categoryFilter = document.getElementById('event-category-filter');
const params = new URLSearchParams(window.location.search);
const searchQuery = `${params.get('q') || ''} ${params.get('lieu') || ''}`.trim();

function normalized(value) {
  return String(value || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLocaleLowerCase('fr');
}

function makeElement(tag, className, text) {
  const element = document.createElement(tag);
  if (className) element.className = className;
  if (text) element.textContent = text;
  return element;
}

function renderEvents(events) {
  const selectedCategory = categoryFilter.value;
  const terms = normalized(searchQuery).split(/\s+/).filter(Boolean);
  const filtered = events.filter((event) => {
    if (selectedCategory && event.category !== selectedCategory) return false;
    const text = normalized(`${event.name} ${event.category} ${event.description} ${event.location}`);
    return terms.every((term) => text.includes(term));
  });

  eventList.replaceChildren();
  filtered.forEach((event, index) => {
    const eventUrl = `../evenement/?eventId=${encodeURIComponent(event.id)}`;
    const row = makeElement('article', `event-row${index === 0 ? ' event-row-featured' : ''}`);
    const image = makeElement('a', `event-thumb ${event.visualClass}`);
    image.href = eventUrl;
    image.setAttribute('aria-label', `Découvrir ${event.name}`);

    const dateBadge = makeElement('div', 'event-date');
    if (event.startDate) {
      const date = new Date(event.startDate.replace(' ', 'T'));
      dateBadge.append(
        makeElement('strong', '', date.toLocaleDateString('fr-FR', { day: '2-digit' })),
        makeElement('span', '', date.toLocaleDateString('fr-FR', { month: 'short' }).replace('.', '').toLocaleUpperCase('fr'))
      );
    }

    const copy = makeElement('div', 'event-copy');
    copy.append(makeElement('span', 'event-type', event.category));
    const heading = makeElement('h2');
    const title = makeElement('a', '', event.name);
    title.href = eventUrl;
    heading.append(title);
    copy.append(heading, makeElement('p', '', event.description));

    if (event.location) copy.append(makeElement('span', 'event-location', event.location));
    const availability = makeElement(
      'span',
      'event-availability',
      event.availableSeats > 0
        ? `${event.availableSeats} places disponibles`
        : 'Aucune séance à venir'
    );
    if (event.availableSeats <= 0) availability.classList.add('is-sold-out');
    copy.append(availability);

    if (event.price !== null) {
      copy.append(makeElement('span', 'event-list-price', `${event.price} € / place`));
    }

    const link = makeElement('a', 'round-link', '↗');
    link.href = eventUrl;
    link.setAttribute('aria-label', `Voir la fiche de ${event.name}`);
    row.append(image, dateBadge, copy, link);
    eventList.append(row);
  });

  if (!filtered.length) {
    eventList.append(makeElement('p', 'search-empty-state', 'Aucun événement ne correspond à votre recherche.'));
  }
}

async function loadEvents() {
  try {
    const result = await window.apiRequest('/api/events');
    const events = result.events || [];
    const categories = [...new Set(events.map((event) => event.category))].sort();
    categories.forEach((category) => {
      const option = makeElement('option', '', category);
      option.value = category;
      categoryFilter.append(option);
    });
    const requestedCategory = params.get('categorie') || '';
    if (categories.includes(requestedCategory)) categoryFilter.value = requestedCategory;
    renderEvents(events);
    categoryFilter.addEventListener('change', () => renderEvents(events));
  } catch (error) {
    eventList.replaceChildren(makeElement('p', 'search-empty-state', `Impossible de charger les événements : ${error.message}`));
  }
}

loadEvents();
