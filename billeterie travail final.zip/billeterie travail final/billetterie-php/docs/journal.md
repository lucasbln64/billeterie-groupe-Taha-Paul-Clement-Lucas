# Journal de projet

> À compléter avec vos dates et le nom de la personne qui a réalisé chaque étape.

| Étape | Contenu | Date | Qui |
|---|---|---|---|
| 1. Cadrage | lecture du cahier des charges, périmètre (sans paiement) | | |
| 2. Maquettes | arborescence, pages accueil / catalogue / fiche, responsive | | |
| 3. HTML/CSS | pages statiques et feuille de style commune | | |
| 4. Base de données | modèle relationnel, `schema.sql`, `seed.sql` | | |
| 5. Back-end | connexion PDO, API PHP, pages dynamiques | | |
| 6. Authentification | inscription, connexion, sessions, rôles | | |
| 7. Réservation | contrôle des places, transaction, historique, billets, annulation | | |
| 8. Back-office | CRUD événements, séances, catégories, salles, statistiques | | |
| 9. Sécurité et tests | CSRF, validation, `tests/api-smoke.php` (55 vérifications) | | |
| 10. Réorganisation | structure par dossier de page, suppression du code inutile | | |
| 11. Documentation | README, architecture, plan de soutenance | | |

## Difficultés rencontrées

- Passage d'un site rendu côté serveur à des pages HTML + API JSON, pour garder du HTML lisible et expliquable.
- Éviter le dépassement de capacité lors de réservations simultanées (transaction + verrou).
- Protéger l'administration côté serveur et pas seulement en cachant des boutons.
- Faire fonctionner PHP, MySQL et Apache en local (noms de base, ports).
