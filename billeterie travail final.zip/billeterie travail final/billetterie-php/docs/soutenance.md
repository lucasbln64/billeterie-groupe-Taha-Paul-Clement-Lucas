# Préparation de la soutenance

## Avant de passer

1. Démarrer MySQL et Apache (XAMPP), puis le site :
   ```powershell
   Set-Location 'C:\Users\hurus\Downloads\BELLETERIE TROBIEN\billetterie-php'
   & 'C:\xampp\php\php.exe' -S 127.0.0.1:8000 -t public
   ```
2. Comptes de démonstration déjà créés (à changer avant toute mise en ligne) :
   - admin : `admin@fete-sorties.test` / `Admin2026!`
   - utilisateur : `camille@fete-sorties.test` / `Camille2026!`
3. Ouvrir http://127.0.0.1:8000/ et tester une réservation une fois avant l'oral.
4. Préparer un onglet phpMyAdmin sur la base pour montrer les tables.
5. Affichage mobile vérifié (390 px, aucun débordement). Captures dans `docs/captures/` (`desktop-*` et `mobile-*` : accueil, événements, événement, connexion, inscription, réservations, admin).

## Plan de présentation collective (≈ 10–15 min, à adapter)

| # | Partie | Durée | Contenu |
|---|---|---|---|
| 1 | Introduction | 1 min | site de billetterie « Fête & Sorties », sans paiement (hors périmètre) |
| 2 | Architecture | 2 min | schéma navigateur → API PHP → MySQL ; front-end vs back-end ; API, JSON, SGBDR |
| 3 | Base de données | 2 min | tables et relations (voir `architecture.md`) |
| 4 | **Démonstration** | 4–5 min | voir ci-dessous |
| 5 | Sécurité | 2 min | hachage, requêtes préparées, session, CSRF, rôle admin |
| 6 | Difficultés | 1 min | voir `journal.md` |
| 7 | Bilan et perspectives | 1 min | acquis ; paiement, QR code, e-mails, place numérotée… |

Chaque membre du groupe doit parler : répartissez les parties et préparez votre contribution personnelle.

## Scénario de démonstration

1. **Visiteur** : accueil → recherche → liste d'événements → filtre par catégorie → fiche événement.
2. **Inscription** puis **connexion**. Montrer une erreur : mauvais mot de passe.
3. **Réservation** : choisir une séance, 2 billets → confirmation → « Mes réservations » → affichage et impression des billets.
4. **Cas d'erreur** : demander plus de places qu'il n'en reste → refus.
5. **Annulation** d'une réservation → la place est libérée.
6. **Droits** : sans connexion, ouvrir `/admin/` → accès refusé.
7. **Admin** : tableau de bord, créer un événement et une séance, modifier ou supprimer.
8. **Mobile** : réduire la fenêtre et montrer le responsive.
9. **Base** : montrer dans phpMyAdmin la réservation et ses billets.

## Questions probables et réponses courtes

- **Client-serveur ?** Le navigateur (client) demande, le serveur PHP répond et accède à la base.
- **Front-end / back-end ?** Front : ce que voit l'utilisateur (HTML/CSS/JS). Back : logique, droits et données (PHP/MySQL).
- **API ?** Des routes qu'un programme appelle pour échanger des données, ici en JSON.
- **SGBDR ?** Système de gestion de base de données relationnelle : tables liées par des clés.
- **DOM ?** Représentation de la page en arbre, que JavaScript lit et modifie.
- **Hachage ?** Transformation à sens unique : on stocke l'empreinte du mot de passe, pas le mot de passe.
- **Injection SQL ?** Évitée par les requêtes préparées (PDO).
- **CSRF ?** Un site tiers pousse le navigateur à envoyer une action ; le jeton secret l'empêche.
- **Sur-réservation ?** Transaction + verrou de la séance pendant la vérification et l'enregistrement.
- **Admin sûr ?** Le rôle est contrôlé par l'API à chaque requête, pas seulement dans l'interface.
- **Pas de paiement ?** Hors périmètre du cahier des charges.
- **Voir les billets d'un autre ?** Non : les requêtes sont filtrées par l'identifiant de la session.

## Tests à citer (cahier des charges p. 36)

Voir `tests/api-smoke.php` : compte valide/invalide, connexion, accès sans authentification, réservation d'autrui, capacité exacte et dépassement, séance inexistante, CRUD admin.

## Limites à assumer

- Pas de paiement, d'e-mail de confirmation ni de QR code.
- Les annonces de l'accueil et de la liste sont écrites en HTML, puis complétées par l'API pour les places et les prix.
- Ajouter des captures d'écran dans `docs/` avant le rendu.
