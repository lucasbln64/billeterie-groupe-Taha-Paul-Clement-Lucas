# Architecture et modèle de données

## Architecture client-serveur

```text
Navigateur (front-end)          Serveur (back-end)               Base de données
HTML / CSS / JavaScript  ──►  public/api/api.php (PHP)  ──►  MySQL / MariaDB
   fetch + JSON + cookie  ◄──   app/functions.php (PDO)  ◄──   tables relationnelles
```

- **Front-end** : pages HTML statiques (un dossier par page). Le JavaScript manipule le DOM et appelle l'API avec `fetch`.
- **Back-end** : une API PHP qui renvoie du JSON. Elle valide les données, contrôle la session et les droits, puis interroge la base avec PDO (requêtes préparées).
- **Base** : MySQL/MariaDB (SGBDR), accessible uniquement par le serveur PHP.

## Routes de l'API (`public/api/api.php`)

| Méthode | Route | Accès | Rôle |
|---|---|---|---|
| GET | `session` | public | utilisateur connecté + jeton CSRF |
| GET | `events` | public | catalogue, séances et places restantes |
| GET | `reservations` | connecté | réservations du compte |
| POST | `inscription`, `connexion`, `deconnexion` | public | compte et session |
| POST | `reservations`, `annulation` | connecté | réserver / annuler |
| GET/POST | `admin/dashboard`, `admin/events`, `admin/sessions`, `admin/categories`, `admin/venues`, `admin/reservations` | **admin** | statistiques et CRUD |

## Modèle de données

```text
categories 1───N evenements 1───N seances N───1 salles
                                    │
utilisateurs 1───N reservations N───┘
                       │
                       1───N billets
```

| Table | Rôle | Colonnes principales |
|---|---|---|
| `utilisateurs` | comptes | email unique, `mot_de_passe_hash`, `role` (user/admin) |
| `categories` | types d'événements | nom unique |
| `salles` | lieux | nom, adresse, ville, accès, **capacité** |
| `evenements` | fiches | titre, accroche, description, visuel, `categorie_id` |
| `seances` | dates d'un événement | `evenement_id`, `salle_id`, début, fin, prix |
| `reservations` | commande d'un utilisateur | `utilisateur_id`, `seance_id`, nb_billets, statut (confirmee/annulee) |
| `billets` | un billet par place | `reservation_id`, numéro, **référence unique** |

Les clés étrangères garantissent la cohérence (on ne peut pas supprimer une catégorie ou une salle encore utilisée).
**Places restantes = capacité de la salle − billets des réservations confirmées de la séance.**

## Règles métier

- Réservation entre 1 et 8 billets, uniquement sur une séance future.
- La vérification des places et l'enregistrement se font dans **une transaction avec verrou** (`FOR UPDATE`) : deux clients ne peuvent pas prendre les mêmes dernières places.
- Une réservation ne peut être annulée que si la séance n'a pas commencé.
- Une séance qui a des réservations ne peut pas être modifiée ni supprimée.

## Sécurité

| Risque | Protection |
|---|---|
| Mots de passe volés | `password_hash` / `password_verify` (jamais stockés en clair) |
| Injection SQL | PDO + requêtes préparées |
| Vol de session | cookie `HttpOnly`, `SameSite=Lax`, identifiant régénéré à la connexion |
| CSRF | jeton obligatoire (en-tête `X-CSRF-Token`) sur toute écriture |
| Accès non autorisé | rôle vérifié par l'API à chaque route admin ; réservations filtrées par compte |
| XSS | affichage via `textContent`, en-tête CSP |
| Données invalides | validation côté serveur (longueurs, types, e-mail) |
