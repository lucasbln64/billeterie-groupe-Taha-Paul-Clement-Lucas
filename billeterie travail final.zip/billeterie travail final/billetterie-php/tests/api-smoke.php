<?php
declare(strict_types=1);

$config = require __DIR__ . '/../config/config.php';
if (preg_match('/_test$/i', (string) $config['db_name']) !== 1) {
    fwrite(STDERR, "Refus d'exécuter les tests : configurez une base dont le nom se termine par _test.\n");
    exit(2);
}

$baseUrl = rtrim(getenv('TEST_BASE_URL') ?: 'http://127.0.0.1:8000/api/api.php', '/');
$assertions = 0;

function check(bool $condition, string $message): void
{
    global $assertions;
    $assertions++;
    if (!$condition) {
        throw new RuntimeException($message);
    }
}

function api_call(array &$cookies, string $route, string $method = 'GET', ?array $payload = null, ?string $csrf = null): array
{
    global $baseUrl;
    $path = (string) parse_url($route, PHP_URL_PATH);
    $query = (string) parse_url($route, PHP_URL_QUERY);
    $url = $baseUrl . '?route=' . rawurlencode($path) . ($query === '' ? '' : '&' . $query);
    $headers = ['Accept: application/json'];
    if ($payload !== null) {
        $headers[] = 'Content-Type: application/json';
    }
    if ($csrf !== null) {
        $headers[] = 'X-CSRF-Token: ' . $csrf;
    }
    if ($cookies) {
        $headers[] = 'Cookie: ' . implode('; ', array_map(
            static fn (string $name, string $value): string => "$name=$value",
            array_keys($cookies),
            array_values($cookies)
        ));
    }
    $context = stream_context_create(['http' => [
        'method' => $method,
        'header' => implode("\r\n", $headers),
        'content' => $payload === null ? '' : json_encode($payload, JSON_THROW_ON_ERROR),
        'ignore_errors' => true,
        'timeout' => 10,
    ]]);
    $body = file_get_contents($url, false, $context);
    $responseHeaders = $http_response_header ?? [];
    $status = 0;
    foreach ($responseHeaders as $header) {
        if (preg_match('/^HTTP\/\S+\s+(\d{3})/', $header, $match)) {
            $status = (int) $match[1];
        }
        if (stripos($header, 'Set-Cookie:') === 0
            && preg_match('/Set-Cookie:\s*([^=;]+)=([^;]*)/i', $header, $cookie)) {
            $cookies[$cookie[1]] = $cookie[2];
        }
    }
    $json = json_decode((string) $body, true);
    return ['status' => $status, 'data' => is_array($json) ? $json : []];
}

try {
    $visitorCookies = [];
    $session = api_call($visitorCookies, 'session');
    check($session['status'] === 200 && is_string($session['data']['csrfToken'] ?? null), 'La session visiteur doit fournir un jeton CSRF.');
    $csrf = $session['data']['csrfToken'];

    $withoutCsrf = api_call($visitorCookies, 'inscription', 'POST', ['email' => 'csrf@example.test']);
    check($withoutCsrf['status'] === 403, 'Une écriture sans jeton CSRF doit être refusée.');
    check(api_call($visitorCookies, 'reservations')['status'] === 401, 'Un visiteur ne doit pas voir les réservations.');
    check(api_call($visitorCookies, 'admin/dashboard')['status'] === 401, 'Un visiteur ne doit pas accéder à l’administration.');

    $events = api_call($visitorCookies, 'events');
    check($events['status'] === 200 && !empty($events['data']['events']), 'Le catalogue doit être disponible.');
    $sessionToBook = null;
    $eventToBook = null;
    foreach ($events['data']['events'] as $event) {
        foreach ($event['sessions'] ?? [] as $eventSession) {
            if (($eventSession['availableSeats'] ?? 0) > 0) {
                $sessionToBook = $eventSession;
                $eventToBook = $event;
                break 2;
            }
        }
    }
    check($sessionToBook !== null, 'La base de test doit contenir une séance future avec des places.');

    $email = 'test-' . bin2hex(random_bytes(5)) . '@example.test';
    $registration = api_call($visitorCookies, 'inscription', 'POST', [
        'prenom' => 'Test',
        'nom' => 'Automatique',
        'email' => $email,
        'password' => 'TestPass123!',
        'passwordConfirmation' => 'TestPass123!',
    ], $csrf);
    check($registration['status'] === 201, 'La création de compte doit réussir.');

    $login = api_call($visitorCookies, 'connexion', 'POST', [
        'email' => $email,
        'password' => 'TestPass123!',
    ], $csrf);
    check($login['status'] === 200, 'La connexion doit réussir.');
    $csrf = (string) ($login['data']['csrfToken'] ?? '');
    check($csrf !== '', 'La connexion doit renouveler le jeton CSRF.');
    check(api_call($visitorCookies, 'admin/dashboard')['status'] === 403, 'Un compte client ne doit pas accéder à l’administration.');

    $booking = api_call($visitorCookies, 'reservations', 'POST', [
        'sessionId' => $sessionToBook['id'],
        'quantity' => 1,
    ], $csrf);
    check($booking['status'] === 201, 'La réservation d’une séance disponible doit réussir.');
    $history = api_call($visitorCookies, 'reservations');
    check($history['status'] === 200 && count($history['data']['reservations'] ?? []) === 1, 'Le compte doit retrouver sa réservation.');
    check(count($history['data']['reservations'][0]['ticketReferences'] ?? []) === 1, 'La réservation doit générer une référence de billet.');
    check(api_call($visitorCookies, 'reservations', 'POST', [
        'sessionId' => $sessionToBook['id'],
        'quantity' => 9,
    ], $csrf)['status'] === 422, 'Une demande supérieure à la limite par réservation doit être refusée.');
    check(api_call($visitorCookies, 'annulation', 'POST', [
        'reservationId' => $booking['data']['reservationId'],
    ], $csrf)['status'] === 200, 'Le propriétaire doit pouvoir annuler sa réservation future.');
    $cancelledHistory = api_call($visitorCookies, 'reservations');
    check(($cancelledHistory['data']['reservations'][0]['cancelled'] ?? false) === true, 'Une annulation doit rester visible dans l’historique.');

    $adminEmail = getenv('TEST_ADMIN_EMAIL') ?: '';
    $adminPassword = getenv('TEST_ADMIN_PASSWORD') ?: '';
    if ($adminEmail !== '' && $adminPassword !== '') {
        $adminCookies = [];
        $adminSession = api_call($adminCookies, 'session');
        $adminLogin = api_call($adminCookies, 'connexion', 'POST', [
            'email' => $adminEmail,
            'password' => $adminPassword,
        ], $adminSession['data']['csrfToken'] ?? null);
        check($adminLogin['status'] === 200, 'La connexion administrateur doit réussir.');
        $adminCsrf = (string) ($adminLogin['data']['csrfToken'] ?? '');

        foreach (['dashboard', 'events', 'categories', 'venues', 'sessions', 'reservations'] as $section) {
            $response = api_call($adminCookies, 'admin/' . $section);
            check($response['status'] === 200, "La lecture admin/$section doit réussir.");
        }
        $dashboard = api_call($adminCookies, 'admin/dashboard?days=30');
        check($dashboard['status'] === 200, 'Le tableau de bord doit retourner les statistiques.');
        check(isset($dashboard['data']['summary']['occupancy'])
            && $dashboard['data']['summary']['occupancy'] >= 0
            && $dashboard['data']['summary']['occupancy'] <= 100,
            'Le tableau de bord doit calculer un taux de remplissage valide.');
        check(api_call($adminCookies, 'admin/events', 'POST', [
            'action' => 'delete',
            'id' => $eventToBook['databaseId'],
        ], $adminCsrf)['status'] === 409, 'Un événement avec un historique de réservations ne doit pas être supprimable.');

        $suffix = bin2hex(random_bytes(4));
        $category = api_call($adminCookies, 'admin/categories', 'POST', ['action' => 'create', 'name' => 'Test ' . $suffix], $adminCsrf);
        check($category['status'] === 201, 'La création admin d’une catégorie doit réussir.');
        $categoryRows = api_call($adminCookies, 'admin/categories')['data']['categories'] ?? [];
        $categoryRow = array_values(array_filter($categoryRows, static fn (array $row): bool => $row['nom'] === 'Test ' . $suffix))[0] ?? null;
        check($categoryRow !== null, 'La catégorie créée doit apparaître dans la liste.');

        $event = api_call($adminCookies, 'admin/events', 'POST', [
            'action' => 'create', 'title' => 'Test ' . $suffix, 'tagline' => 'Test',
            'description' => 'Événement de test', 'visual' => 'festival', 'categoryId' => $categoryRow['id'],
        ], $adminCsrf);
        check($event['status'] === 201, 'La création admin d’un événement doit réussir.');
        $eventId = (int) ($event['data']['id'] ?? 0);
        $venue = api_call($adminCookies, 'admin/venues', 'POST', [
            'action' => 'create', 'name' => 'Salle test ' . $suffix, 'address' => '1 rue du test',
            'city' => 'Bordeaux', 'access' => '', 'capacity' => 10,
        ], $adminCsrf);
        check($venue['status'] === 201, 'La création admin d’une salle doit réussir.');
        $venueRows = api_call($adminCookies, 'admin/venues')['data']['venues'] ?? [];
        $venueRow = array_values(array_filter($venueRows, static fn (array $row): bool => $row['nom'] === 'Salle test ' . $suffix))[0] ?? null;
        check($venueRow !== null, 'La salle créée doit apparaître dans la liste.');

        $sessionCreate = api_call($adminCookies, 'admin/sessions', 'POST', [
            'action' => 'create', 'eventId' => $eventId, 'venueId' => $venueRow['id'],
            'start' => '2099-06-01T18:00', 'end' => '2099-06-01T21:00', 'price' => 12,
        ], $adminCsrf);
        check($sessionCreate['status'] === 201, 'La création admin d’une séance doit réussir.');
        $sessionRows = api_call($adminCookies, 'admin/sessions')['data']['sessions'] ?? [];
        $createdSession = array_values(array_filter($sessionRows, static fn (array $row): bool => (int) $row['evenement_id'] === $eventId))[0] ?? null;
        check($createdSession !== null, 'La séance créée doit apparaître dans la liste.');

        $sessionUpdate = api_call($adminCookies, 'admin/sessions', 'POST', [
            'action' => 'update', 'id' => $createdSession['id'], 'eventId' => $eventId,
            'venueId' => $venueRow['id'], 'start' => '2099-06-01T19:00',
            'end' => '2099-06-01T22:00', 'price' => 15,
        ], $adminCsrf);
        check($sessionUpdate['status'] === 200, 'La modification admin d’une séance doit réussir.');
        check(api_call($adminCookies, 'admin/sessions', 'POST', ['action' => 'delete', 'id' => $createdSession['id']], $adminCsrf)['status'] === 200, 'La suppression admin d’une séance doit réussir.');
        check(api_call($adminCookies, 'admin/events', 'POST', [
            'action' => 'update', 'id' => $eventId, 'title' => 'Test modifié ' . $suffix,
            'tagline' => 'Test', 'description' => 'Événement modifié',
            'visual' => 'jazz', 'categoryId' => $categoryRow['id'],
        ], $adminCsrf)['status'] === 200, 'La modification admin d’un événement doit réussir.');
        check(api_call($adminCookies, 'admin/events', 'POST', ['action' => 'delete', 'id' => $eventId], $adminCsrf)['status'] === 200, 'La suppression admin d’un événement doit réussir.');
        check(api_call($adminCookies, 'admin/venues', 'POST', ['action' => 'update', 'id' => $venueRow['id'], 'name' => 'Salle test modifiée ' . $suffix, 'address' => '1 rue du test', 'city' => 'Bordeaux', 'access' => '', 'capacity' => 12], $adminCsrf)['status'] === 200, 'La modification admin d’une salle doit réussir.');
        check(api_call($adminCookies, 'admin/venues', 'POST', ['action' => 'delete', 'id' => $venueRow['id']], $adminCsrf)['status'] === 200, 'La suppression admin d’une salle doit réussir.');
        check(api_call($adminCookies, 'admin/categories', 'POST', ['action' => 'update', 'id' => $categoryRow['id'], 'name' => 'Catégorie test ' . $suffix], $adminCsrf)['status'] === 200, 'La modification admin d’une catégorie doit réussir.');
        check(api_call($adminCookies, 'admin/categories', 'POST', ['action' => 'delete', 'id' => $categoryRow['id']], $adminCsrf)['status'] === 200, 'La suppression admin d’une catégorie doit réussir.');

        $capacityCategory = api_call($adminCookies, 'admin/categories', 'POST', ['action' => 'create', 'name' => 'Capacité ' . $suffix], $adminCsrf);
        check($capacityCategory['status'] === 201, 'La catégorie du test de capacité doit être créée.');
        $capacityCategories = api_call($adminCookies, 'admin/categories')['data']['categories'] ?? [];
        $capacityCategoryRow = array_values(array_filter($capacityCategories, static fn (array $row): bool => $row['nom'] === 'Capacité ' . $suffix))[0] ?? null;
        check($capacityCategoryRow !== null, 'La catégorie du test de capacité doit être retrouvée.');
        $capacityEvent = api_call($adminCookies, 'admin/events', 'POST', [
            'action' => 'create', 'title' => 'Événement capacité ' . $suffix, 'tagline' => 'Test capacité',
            'description' => 'Événement temporaire de test', 'visual' => 'festival',
            'categoryId' => $capacityCategoryRow['id'],
        ], $adminCsrf);
        check($capacityEvent['status'] === 201, 'L’événement du test de capacité doit être créé.');
        $capacityEventId = (int) $capacityEvent['data']['id'];
        $capacityVenue = api_call($adminCookies, 'admin/venues', 'POST', [
            'action' => 'create', 'name' => 'Salle capacité ' . $suffix,
            'address' => '2 rue du test', 'city' => 'Bordeaux', 'access' => '', 'capacity' => 2,
        ], $adminCsrf);
        check($capacityVenue['status'] === 201, 'La salle du test de capacité doit être créée.');
        $capacityVenues = api_call($adminCookies, 'admin/venues')['data']['venues'] ?? [];
        $capacityVenueRow = array_values(array_filter($capacityVenues, static fn (array $row): bool => $row['nom'] === 'Salle capacité ' . $suffix))[0] ?? null;
        check($capacityVenueRow !== null, 'La salle du test de capacité doit être retrouvée.');
        check(api_call($adminCookies, 'admin/sessions', 'POST', [
            'action' => 'create', 'eventId' => $capacityEventId, 'venueId' => $capacityVenueRow['id'],
            'start' => '2099-07-01T18:00', 'end' => '2099-07-01T21:00', 'price' => 10,
        ], $adminCsrf)['status'] === 201, 'La séance du test de capacité doit être créée.');
        $capacityEvents = api_call($visitorCookies, 'events')['data']['events'] ?? [];
        $capacityEventData = array_values(array_filter($capacityEvents, static fn (array $row): bool => (int) $row['databaseId'] === $capacityEventId))[0] ?? null;
        check(!empty($capacityEventData['sessions'][0]['id']), 'La séance du test de capacité doit être visible côté public.');
        $capacitySessionId = $capacityEventData['sessions'][0]['id'];
        $twoSeats = api_call($visitorCookies, 'reservations', 'POST', [
            'sessionId' => $capacitySessionId, 'quantity' => 2,
        ], $csrf);
        check($twoSeats['status'] === 201, 'La réservation des deux places disponibles doit réussir.');
        check(api_call($visitorCookies, 'reservations', 'POST', [
            'sessionId' => $capacitySessionId, 'quantity' => 1,
        ], $csrf)['status'] === 422, 'Une réservation supplémentaire lorsque la salle est complète doit échouer.');
        check(api_call($adminCookies, 'admin/venues', 'POST', [
            'action' => 'update', 'id' => $capacityVenueRow['id'], 'name' => 'Salle capacité ' . $suffix,
            'address' => '2 rue du test', 'city' => 'Bordeaux', 'access' => '', 'capacity' => 1,
        ], $adminCsrf)['status'] === 409, 'La capacité ne peut pas passer sous le nombre de billets déjà vendus.');
        check(api_call($adminCookies, 'admin/sessions', 'POST', [
            'action' => 'delete', 'id' => $capacitySessionId,
        ], $adminCsrf)['status'] === 409, 'Une séance avec des réservations ne doit pas être supprimable.');
        check(api_call($visitorCookies, 'annulation', 'POST', [
            'reservationId' => $twoSeats['data']['reservationId'],
        ], $csrf)['status'] === 200, 'Le client doit pouvoir annuler ses billets de test.');
        check(api_call($adminCookies, 'admin/events', 'POST', [
            'action' => 'delete', 'id' => $capacityEventId,
        ], $adminCsrf)['status'] === 409, 'Un événement avec un historique ne doit pas être supprimable.');
        check(api_call($adminCookies, 'admin/categories', 'POST', [
            'action' => 'delete', 'id' => $capacityCategoryRow['id'],
        ], $adminCsrf)['status'] === 409, 'Une catégorie utilisée par un événement ne doit pas être supprimable.');
    } else {
        fwrite(STDOUT, "Tests admin détaillés ignorés : définissez TEST_ADMIN_EMAIL et TEST_ADMIN_PASSWORD.\n");
    }

    fwrite(STDOUT, "OK — $assertions assertions API.\n");
} catch (Throwable $exception) {
    fwrite(STDERR, "ÉCHEC après $assertions assertions : {$exception->getMessage()}\n");
    exit(1);
}
